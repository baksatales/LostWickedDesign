export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      badges: {
        Row: {
          active: boolean
          created_at: string
          description: string
          id: string
          label: string
          slug: string
          tone: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          description?: string
          id?: string
          label: string
          slug: string
          tone?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          description?: string
          id?: string
          label?: string
          slug?: string
          tone?: string
        }
        Relationships: []
      }
      course_enrolments: {
        Row: {
          baksa_share_inr: number
          card_last4: string
          course_id: string
          created_at: string
          creator_share_inr: number
          id: string
          payment_ref: string
          price_inr: number
          shopper_id: string
        }
        Insert: {
          baksa_share_inr: number
          card_last4: string
          course_id: string
          created_at?: string
          creator_share_inr: number
          id?: string
          payment_ref: string
          price_inr: number
          shopper_id: string
        }
        Update: {
          baksa_share_inr?: number
          card_last4?: string
          course_id?: string
          created_at?: string
          creator_share_inr?: number
          id?: string
          payment_ref?: string
          price_inr?: number
          shopper_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "course_enrolments_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          booked: number
          created_at: string
          creator_name: string
          description: string
          format: string
          id: string
          maker_id: string | null
          meeting_link: string | null
          price_inr: number
          review_note: string | null
          schedule: string
          seats: number
          status: string
          title: string
        }
        Insert: {
          booked?: number
          created_at?: string
          creator_name: string
          description?: string
          format: string
          id?: string
          maker_id?: string | null
          meeting_link?: string | null
          price_inr: number
          review_note?: string | null
          schedule?: string
          seats?: number
          status?: string
          title: string
        }
        Update: {
          booked?: number
          created_at?: string
          creator_name?: string
          description?: string
          format?: string
          id?: string
          maker_id?: string | null
          meeting_link?: string | null
          price_inr?: number
          review_note?: string | null
          schedule?: string
          seats?: number
          status?: string
          title?: string
        }
        Relationships: []
      }
      leads: {
        Row: {
          contact: string
          created_at: string
          details: string | null
          id: string
          kind: string
          name: string
        }
        Insert: {
          contact: string
          created_at?: string
          details?: string | null
          id?: string
          kind: string
          name: string
        }
        Update: {
          contact?: string
          created_at?: string
          details?: string | null
          id?: string
          kind?: string
          name?: string
        }
        Relationships: []
      }
      maker_badges: {
        Row: {
          badge_id: string
          created_at: string
          maker_id: string
        }
        Insert: {
          badge_id: string
          created_at?: string
          maker_id: string
        }
        Update: {
          badge_id?: string
          created_at?: string
          maker_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "maker_badges_badge_id_fkey"
            columns: ["badge_id"]
            isOneToOne: false
            referencedRelation: "badges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "maker_badges_maker_id_fkey"
            columns: ["maker_id"]
            isOneToOne: false
            referencedRelation: "makers"
            referencedColumns: ["id"]
          },
        ]
      }
      makers: {
        Row: {
          bio: string
          brand: string
          craft: string
          created_at: string
          id: string
          image_key: string | null
          is_founding: boolean
          published: boolean
          story: string
          tagline: string
          techniques: string[]
        }
        Insert: {
          bio?: string
          brand: string
          craft?: string
          created_at?: string
          id: string
          image_key?: string | null
          is_founding?: boolean
          published?: boolean
          story?: string
          tagline?: string
          techniques?: string[]
        }
        Update: {
          bio?: string
          brand?: string
          craft?: string
          created_at?: string
          id?: string
          image_key?: string | null
          is_founding?: boolean
          published?: boolean
          story?: string
          tagline?: string
          techniques?: string[]
        }
        Relationships: []
      }
      order_items: {
        Row: {
          commission_inr: number
          created_at: string
          fulfilment: string
          fulfilment_updated_at: string | null
          gateway_fee_inr: number
          id: string
          line_total_inr: number
          maker_id: string
          order_id: string
          product_id: string
          product_name: string
          quantity: number
          seller_earnings_inr: number
          unit_price_inr: number
        }
        Insert: {
          commission_inr: number
          created_at?: string
          fulfilment?: string
          fulfilment_updated_at?: string | null
          gateway_fee_inr: number
          id?: string
          line_total_inr: number
          maker_id: string
          order_id: string
          product_id: string
          product_name: string
          quantity: number
          seller_earnings_inr: number
          unit_price_inr: number
        }
        Update: {
          commission_inr?: number
          created_at?: string
          fulfilment?: string
          fulfilment_updated_at?: string | null
          gateway_fee_inr?: number
          id?: string
          line_total_inr?: number
          maker_id?: string
          order_id?: string
          product_id?: string
          product_name?: string
          quantity?: number
          seller_earnings_inr?: number
          unit_price_inr?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          card_last4: string
          commission_inr: number
          commission_pct: number
          created_at: string
          gateway_fee_inr: number
          gateway_fee_pct: number
          gift_note: string | null
          id: string
          payment_ref: string
          quiz_answers: Json | null
          recipient_name: string
          seller_earnings_inr: number
          ship_address: string
          shopper_id: string
          status: string
          subtotal_inr: number
        }
        Insert: {
          card_last4: string
          commission_inr: number
          commission_pct: number
          created_at?: string
          gateway_fee_inr: number
          gateway_fee_pct: number
          gift_note?: string | null
          id?: string
          payment_ref: string
          quiz_answers?: Json | null
          recipient_name: string
          seller_earnings_inr: number
          ship_address: string
          shopper_id: string
          status?: string
          subtotal_inr: number
        }
        Update: {
          card_last4?: string
          commission_inr?: number
          commission_pct?: number
          created_at?: string
          gateway_fee_inr?: number
          gateway_fee_pct?: number
          gift_note?: string | null
          id?: string
          payment_ref?: string
          quiz_answers?: Json | null
          recipient_name?: string
          seller_earnings_inr?: number
          ship_address?: string
          shopper_id?: string
          status?: string
          subtotal_inr?: number
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          academy_share_pct: number
          commission_pct: number
          gateway_fee_pct: number
          id: number
          updated_at: string
        }
        Insert: {
          academy_share_pct?: number
          commission_pct?: number
          gateway_fee_pct?: number
          id?: number
          updated_at?: string
        }
        Update: {
          academy_share_pct?: number
          commission_pct?: number
          gateway_fee_pct?: number
          id?: number
          updated_at?: string
        }
        Relationships: []
      }
      products: {
        Row: {
          created_at: string
          description: string
          feelings: string[]
          id: string
          image_key: string | null
          image_url: string | null
          maker_id: string
          maker_name: string
          name: string
          occasions: string[]
          price_inr: number
          recipients: string[]
          review_note: string | null
          reviewed_at: string | null
          status: string
          stock: number
        }
        Insert: {
          created_at?: string
          description?: string
          feelings?: string[]
          id?: string
          image_key?: string | null
          image_url?: string | null
          maker_id: string
          maker_name?: string
          name: string
          occasions?: string[]
          price_inr: number
          recipients?: string[]
          review_note?: string | null
          reviewed_at?: string | null
          status?: string
          stock?: number
        }
        Update: {
          created_at?: string
          description?: string
          feelings?: string[]
          id?: string
          image_key?: string | null
          image_url?: string | null
          maker_id?: string
          maker_name?: string
          name?: string
          occasions?: string[]
          price_inr?: number
          recipients?: string[]
          review_note?: string | null
          reviewed_at?: string | null
          status?: string
          stock?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string
          id: string
          studio_name: string | null
        }
        Insert: {
          created_at?: string
          display_name?: string
          id: string
          studio_name?: string | null
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          studio_name?: string | null
        }
        Relationships: []
      }
      return_requests: {
        Row: {
          created_at: string
          id: string
          maker_id: string
          maker_note: string | null
          order_item_id: string
          reason: string
          shopper_id: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          maker_id: string
          maker_note?: string | null
          order_item_id: string
          reason: string
          shopper_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          maker_id?: string
          maker_note?: string | null
          order_item_id?: string
          reason?: string
          shopper_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "return_requests_order_item_id_fkey"
            columns: ["order_item_id"]
            isOneToOne: true
            referencedRelation: "order_items"
            referencedColumns: ["id"]
          },
        ]
      }
      site_content: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      site_pages: {
        Row: {
          body: string
          created_at: string
          footer_column: string | null
          id: string
          kind: string
          published: boolean
          slug: string
          sort: number
          title: string
          updated_at: string
        }
        Insert: {
          body?: string
          created_at?: string
          footer_column?: string | null
          id?: string
          kind?: string
          published?: boolean
          slug: string
          sort?: number
          title: string
          updated_at?: string
        }
        Update: {
          body?: string
          created_at?: string
          footer_column?: string | null
          id?: string
          kind?: string
          published?: boolean
          slug?: string
          sort?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_exists: { Args: never; Returns: boolean }
      claim_admin: { Args: never; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      record_enrolment: { Args: { p: Json }; Returns: string }
      record_order: { Args: { p_items: Json; p_order: Json }; Returns: string }
      request_return: {
        Args: { _order_item_id: string; _reason: string }
        Returns: string
      }
      update_fulfilment: {
        Args: { _order_item_id: string; _status: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "maker" | "shopper"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "maker", "shopper"],
    },
  },
} as const
