import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type Role = "admin" | "maker" | "shopper";
type AuthState = { user: User | null; roles: Role[]; loading: boolean; refreshRoles: () => Promise<void>; signOut: () => Promise<void> };

const Ctx = createContext<AuthState>({ user: null, roles: [], loading: true, refreshRoles: async () => {}, signOut: async () => {} });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);

  const loadRoles = useCallback(async (u: User | null) => {
    if (!u) { setRoles([]); return; }
    const { data } = await supabase.from("user_roles").select("role").eq("user_id", u.id);
    setRoles((data ?? []).map((r) => r.role as Role));
  }, []);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      const u = session?.user ?? null;
      setUser(u);
      setTimeout(() => { void loadRoles(u).finally(() => setLoading(false)); }, 0);
    });
    supabase.auth.getSession().then(({ data }) => {
      const u = data.session?.user ?? null;
      setUser(u);
      void loadRoles(u).finally(() => setLoading(false));
    });
    return () => sub.subscription.unsubscribe();
  }, [loadRoles]);

  return (
    <Ctx.Provider value={{ user, roles, loading, refreshRoles: () => loadRoles(user), signOut: async () => { await supabase.auth.signOut(); } }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);
