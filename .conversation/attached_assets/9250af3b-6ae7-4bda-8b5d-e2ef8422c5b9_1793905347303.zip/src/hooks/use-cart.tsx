import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type CartLine = { productId: string; name: string; price: number; imageUrl: string; maker: string; quantity: number };
type CartState = {
  lines: CartLine[];
  quiz: Record<string, string> | null;
  add: (l: Omit<CartLine, "quantity">) => void;
  setQty: (id: string, q: number) => void;
  remove: (id: string) => void;
  clear: () => void;
  setQuiz: (q: Record<string, string> | null) => void;
};
const Ctx = createContext<CartState | null>(null);
const KEY = "baksa-bag-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [quiz, setQuiz] = useState<Record<string, string> | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try { const s = JSON.parse(localStorage.getItem(KEY) || "{}"); setLines(s.lines ?? []); setQuiz(s.quiz ?? null); } catch { /* ignore */ }
    setReady(true);
  }, []);
  useEffect(() => { if (ready) localStorage.setItem(KEY, JSON.stringify({ lines, quiz })); }, [lines, quiz, ready]);

  const value: CartState = {
    lines, quiz, setQuiz,
    add: (l) => setLines((cur) => cur.some((x) => x.productId === l.productId)
      ? cur.map((x) => x.productId === l.productId ? { ...x, quantity: Math.min(20, x.quantity + 1) } : x)
      : [...cur, { ...l, quantity: 1 }]),
    setQty: (id, q) => setLines((cur) => cur.map((x) => x.productId === id ? { ...x, quantity: Math.max(1, Math.min(20, q)) } : x)),
    remove: (id) => setLines((cur) => cur.filter((x) => x.productId !== id)),
    clear: () => { setLines([]); setQuiz(null); },
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart outside CartProvider");
  return c;
}
