import { describe, expect, it } from "vitest";
import { splitLine, splitOrder } from "@/lib/pricing";
import { chargeTestCard, TEST_CARD_DECLINE, TEST_CARD_SUCCESS } from "@/lib/test-payment";
import { recommend, type Product } from "@/lib/catalog";

const fees = { commissionPct: 12, gatewayFeePct: 2 };

describe("commission and seller earnings", () => {
  it("takes 12% commission and 2% payment fee, maker keeps the rest", () => {
    expect(splitLine({ unitPrice: 2400, quantity: 1 }, fees)).toEqual({ lineTotal: 2400, commission: 288, gatewayFee: 48, sellerEarnings: 2064 });
  });
  it("multiplies by quantity before splitting", () => {
    expect(splitLine({ unitPrice: 1200, quantity: 3 }, fees).sellerEarnings).toBe(3096);
  });
  it("rounds to paise and keeps the order balanced", () => {
    const o = splitOrder([{ unitPrice: 999, quantity: 1 }, { unitPrice: 1555, quantity: 2 }], fees);
    expect(o.subtotal).toBe(4109);
    expect(Math.round((o.commission + o.gatewayFee + o.sellerEarnings) * 100)).toBe(410900);
  });
  it("rejects zero quantity", () => {
    expect(() => splitLine({ unitPrice: 100, quantity: 0 }, fees)).toThrow();
  });
});

describe("test payment", () => {
  const card = { number: TEST_CARD_SUCCESS, expiry: "12/30", cvc: "123", name: "Asha Rao" };
  const now = new Date("2026-11-05");
  it("succeeds with 4242 card and returns last four", () => {
    const r = chargeTestCard(card, 2400, now);
    expect(r.ok && r.last4).toBe("4242");
  });
  it("declines the 0002 card", () => {
    expect(chargeTestCard({ ...card, number: TEST_CARD_DECLINE }, 2400, now).ok).toBe(false);
  });
  it("rejects an expired card", () => {
    expect(chargeTestCard({ ...card, expiry: "01/25" }, 2400, now).ok).toBe(false);
  });
  it("rejects a number that fails the checksum", () => {
    expect(chargeTestCard({ ...card, number: "4242424242424241" }, 2400, now).ok).toBe(false);
  });
});

const base: Product = {
  id: "1", maker_id: "m", maker_name: "M", name: "A", description: "", price_inr: 1200, stock: 5,
  image_key: null, image_url: null, recipients: ["friend"], occasions: ["birthday"], feelings: ["heart"], status: "approved",
};

describe("four-question gift finder", () => {
  it("only suggests approved, in-stock products", () => {
    const list = [base, { ...base, id: "2", status: "pending" }, { ...base, id: "3", stock: 0 }];
    expect(recommend(list, { occ: "birthday", budget: "b1" }).map((r) => r.product.id)).toEqual(["1"]);
  });
  it("never suggests on recipient and budget alone", () => {
    expect(recommend([base], { rec: "friend", occ: "wedding", feel: "soother", budget: "b1" })).toHaveLength(0);
  });
  it("hides products more than 10% over the budget ceiling", () => {
    expect(recommend([{ ...base, price_inr: 1700 }], { occ: "birthday", budget: "b1" })).toHaveLength(0);
  });
  it("ranks a full match above a partial one", () => {
    const partial = { ...base, id: "p", feelings: ["explorer"], recipients: ["parent"] };
    const r = recommend([partial, base], { rec: "friend", occ: "birthday", feel: "heart", budget: "b1" });
    expect(r[0]?.product.id).toBe("1");
  });
});

import { splitCourse, pieceProfit, breakEven } from "@/lib/pricing";
describe("academy and growth rules", () => {
  it("Baksa keeps 30% of a ₹1,500 class, creator keeps ₹1,050", () => {
    expect(splitCourse(1500, 30)).toEqual({ price: 1500, baksaShare: 450, creatorShare: 1050 });
  });
  it("piece profit deducts 12% + 2% fees and costs", () => {
    const r = pieceProfit({ price: 1000, materials: 200, labour: 150, packaging: 50, shipping: 100 }, { commissionPct: 12, gatewayFeePct: 2 });
    expect(r.fees).toBe(140); expect(r.profit).toBe(360);
  });
  it("break-even rounds up to whole pieces", () => {
    expect(breakEven(10000, 360)).toBe(28);
    expect(breakEven(10000, 0)).toBe(Infinity);
  });
});
