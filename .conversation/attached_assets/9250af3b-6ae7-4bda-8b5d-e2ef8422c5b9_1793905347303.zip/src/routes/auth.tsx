import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/auth")({
  validateSearch: z.object({ as: z.enum(["maker", "shopper"]).optional(), next: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Sign in — Baksa Tales" },
      { name: "description", content: "Sign in or create a Baksa Tales account as a shopper or a maker." },
      { property: "og:title", content: "Sign in — Baksa Tales" },
      { property: "og:description", content: "Sign in or create a Baksa Tales account as a shopper or a maker." },
    ],
  }),
  component: AuthPage,
});

const safeNext = (n?: string) => (n && n.startsWith("/") && !n.startsWith("//") ? n : "/");

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">(search.as ? "signup" : "signin");
  const [role, setRole] = useState<"maker" | "shopper">(search.as ?? "shopper");
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [name, setName] = useState(""); const [studio, setStudio] = useState("");
  const [busy, setBusy] = useState(false); const [sent, setSent] = useState(false);

  useEffect(() => { if (user) navigate({ to: safeNext(search.next) }); }, [user]); // eslint-disable-line react-hooks/exhaustive-deps

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { data, error } = await supabase.auth.signUp({
          email, password,
          options: { emailRedirectTo: window.location.origin, data: { role, display_name: name, studio_name: role === "maker" ? studio : null } },
        });
        if (error) throw error;
        if (!data.session) setSent(true);
      }
    } catch (err) { toast.error(err instanceof Error ? err.message : "Something went wrong"); }
    finally { setBusy(false); }
  }

  async function google() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) toast.error("Google sign-in didn’t work. Try email instead.");
  }

  if (sent) return (
    <main className="mx-auto max-w-md px-5 py-24 text-center">
      <h1 className="text-4xl">Check your email</h1>
      <p className="mt-4 text-muted-foreground">We sent a confirmation link to {email}. Open it to finish creating your account.</p>
    </main>
  );

  return (
    <main className="mx-auto max-w-md px-5 py-16">
      <h1 className="text-5xl">{mode === "signin" ? "Welcome back" : "Join Baksa Tales"}</h1>
      <div className="mt-8 rounded-lg border bg-card p-6 shadow-soft">
        {mode === "signup" && (
          <div className="mb-6 grid grid-cols-2 gap-2 rounded-lg bg-secondary p-1" role="radiogroup" aria-label="Account type">
            {(["shopper", "maker"] as const).map((r) => (
              <button key={r} type="button" role="radio" aria-checked={role === r} onClick={() => setRole(r)}
                className={cn("rounded-md py-2.5 font-slab text-sm transition-colors", role === r ? "bg-card shadow-sm" : "text-muted-foreground")}>
                {r === "shopper" ? "I’m shopping" : "I’m a maker"}
              </button>
            ))}
          </div>
        )}
        <form onSubmit={submit} className="space-y-4">
          {mode === "signup" && <div className="space-y-1.5"><Label htmlFor="n">Your name</Label><Input id="n" required value={name} onChange={(e) => setName(e.target.value)} /></div>}
          {mode === "signup" && role === "maker" && <div className="space-y-1.5"><Label htmlFor="st">Studio name</Label><Input id="st" required value={studio} onChange={(e) => setStudio(e.target.value)} /></div>}
          <div className="space-y-1.5"><Label htmlFor="e">Email</Label><Input id="e" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div className="space-y-1.5"><Label htmlFor="p">Password</Label><Input id="p" type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          <Button type="submit" className="w-full font-slab" disabled={busy}>{busy ? "Please wait…" : mode === "signin" ? "Sign in" : role === "maker" ? "Open my studio" : "Create account"}</Button>
        </form>
        {(mode === "signin" || role === "shopper") && (
          <>
            <div className="my-5 flex items-center gap-3 text-sm text-muted-foreground"><span className="h-px flex-1 bg-border" />or<span className="h-px flex-1 bg-border" /></div>
            <button type="button" onClick={google}
              className="flex h-11 w-full items-center justify-center gap-2.5 rounded-md border border-[#747775] bg-[#FFFFFF] px-3 text-sm font-medium text-[#1F1F1F]">
              <svg aria-hidden="true" width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"/><path fill="#FBBC05" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"/><path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"/></svg>
              Continue with Google
            </button>
          </>
        )}
      </div>
      <p className="mt-6 text-center text-muted-foreground">
        {mode === "signin" ? "New here? " : "Already have an account? "}
        <button className="font-slab text-sm text-primary hover:underline" onClick={() => setMode(mode === "signin" ? "signup" : "signin")}>
          {mode === "signin" ? "Create an account" : "Sign in"}
        </button>
      </p>
    </main>
  );
}
