import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { QUIZ_STEPS, RECIP, OCC, FEEL, BUDGET, recommend, type QuizAnswers } from "@/lib/catalog";
import { approvedProductsQuery } from "@/lib/queries";
import { ProductCard } from "@/components/product-card";
import { useCart } from "@/hooks/use-cart";
import { cn } from "@/lib/utils";

const Search = z.object({
  rec: z.string().optional(), occ: z.string().optional(), feel: z.string().optional(), budget: z.string().optional(),
});

export const Route = createFileRoute("/finder")({
  validateSearch: Search,
  head: () => ({
    meta: [
      { title: "Gift finder — Baksa Tales" },
      { name: "description", content: "Four questions to a shortlist of handmade gifts that fit the person and the moment." },
      { property: "og:title", content: "Gift finder — Baksa Tales" },
      { property: "og:description", content: "Four questions to a shortlist of handmade gifts that fit the person and the moment." },
    ],
  }),
  component: Finder,
});

function Finder() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/finder" });
  const { setQuiz } = useCart();
  const a = search as QuizAnswers;
  const firstOpen = QUIZ_STEPS.findIndex((s) => !a[s.key as keyof QuizAnswers]);
  const [step, setStep] = useState(firstOpen === -1 ? QUIZ_STEPS.length : firstOpen);
  useEffect(() => { if (firstOpen === -1) setStep(QUIZ_STEPS.length); }, [firstOpen]);
  const { data: products } = useQuery(approvedProductsQuery);
  const results = useMemo(() => recommend(products ?? [], a), [products, a.rec, a.occ, a.feel, a.budget]);
  const done = step >= QUIZ_STEPS.length;
  useEffect(() => { if (done) setQuiz({ ...search } as Record<string, string>); }, [done]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!done) {
    const st = QUIZ_STEPS[step]!;
    return (
      <main className="mx-auto max-w-3xl px-5 py-16 md:py-24">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="font-slab text-sm text-muted-foreground">Question {step + 1} of {QUIZ_STEPS.length}</p>
          <Link to="/shop" className="font-slab text-sm text-primary hover:underline">Skip and see all gifts</Link>
        </div>
        <div className="mt-4 grid grid-cols-4 gap-2" aria-hidden>
          {QUIZ_STEPS.map((_, i) => <i key={i} className={cn("h-1.5 rounded-full transition-colors", i <= step ? "bg-primary" : "bg-border")} />)}
        </div>
        <h1 key={st.key} className="mt-10 text-4xl md:text-6xl animate-rise">{st.q}</h1>
        <div className="mt-10 grid gap-3 sm:grid-cols-2">
          {Object.entries(st.opts).map(([k, v]) => {
            const sel = a[st.key as keyof QuizAnswers] === k;
            return (
              <button key={k}
                onClick={() => { navigate({ search: (prev) => ({ ...prev, [st.key]: k }), replace: true }); setStep(step + 1); }}
                className={cn("min-h-16 rounded-lg border bg-card px-5 py-4 text-left text-xl transition-all hover:-translate-y-0.5 hover:border-primary hover:shadow-soft",
                  sel && "border-primary bg-accent")}>
                {v as string}
              </button>
            );
          })}
        </div>
        {step > 0 && <button className="mt-8 font-slab text-sm text-muted-foreground hover:text-primary" onClick={() => setStep(step - 1)}>← Back</button>}
      </main>
    );
  }

  const summary = [a.rec && RECIP[a.rec], a.occ && OCC[a.occ]].filter(Boolean).join(", ");
  return (
    <main className="mx-auto max-w-6xl px-5 py-14">
      <p className="eyebrow">Your shortlist</p>
      <h1 className="mt-2 text-4xl md:text-5xl">{results.length ? `${results.length} gifts picked for you` : "Nothing quite fits yet"}</h1>
      <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border bg-card p-4">
        <p className="flex-1">{summary}{a.feel ? `. ${FEEL[a.feel]}` : ""}. {a.budget && BUDGET[a.budget].label}.</p>
        <button className="font-slab text-sm text-primary hover:underline" onClick={() => { navigate({ search: {} }); setStep(0); }}>Change answers</button>
      </div>
      {results.length ? (
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((r) => <ProductCard key={r.product.id} p={r.product} reasons={r.reasons} />)}
        </div>
      ) : (
        <div className="mt-10 rounded-lg border border-dashed p-12 text-center text-muted-foreground">
          Try a different occasion or what you’d like the gift to do, or <Link to="/shop" className="text-primary underline">browse every gift</Link>.
        </div>
      )}
    </main>
  );
}
