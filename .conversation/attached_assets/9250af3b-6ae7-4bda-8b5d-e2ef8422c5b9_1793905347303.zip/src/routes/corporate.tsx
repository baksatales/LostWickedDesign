import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Gift, PenLine, Truck } from "lucide-react";
import { siteContentQuery } from "@/lib/queries";
import { LeadForm } from "@/components/lead-form";

export const Route = createFileRoute("/corporate")({
  head: () => ({
    meta: [
      { title: "Corporate gifting — handmade, personalised, on time | Baksa Tales" },
      { name: "description", content: "Share your occasion, headcount and budget and we match you with Indian makers who can deliver handmade corporate gifts." },
      { property: "og:title", content: "Corporate gifting — Baksa Tales" },
      { property: "og:description", content: "Handmade corporate gifts from independent Indian makers, matched to your brief." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Corporate,
});

function Corporate() {
  const { data } = useQuery(siteContentQuery);
  const c = data?.corporate ?? {};
  return (
    <main className="mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-2">
      <div>
        <p className="eyebrow">For businesses</p>
        <h1 className="mt-3 text-5xl">{c.title ?? "Corporate gifting"}</h1>
        <p className="mt-4 text-lg text-muted-foreground">{c.body}</p>
        <ul className="mt-8 space-y-5">
          {[{ i: PenLine, t: "Tell us the brief", d: "Occasion, headcount, budget per gift, delivery date." },
            { i: Gift, t: "We match makers", d: "A shortlist of studios who can make it at your volume." },
            { i: Truck, t: "Personalised and delivered", d: "Your logo or note, packed to travel, to one address or many." }].map(({ i: I, t, d }) => (
            <li key={t} className="flex gap-4"><span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary"><I className="h-5 w-5" /></span><div><p className="font-semibold">{t}</p><p className="text-sm text-muted-foreground">{d}</p></div></li>
          ))}
        </ul>
      </div>
      <div className="h-fit rounded-3xl border bg-card p-8 shadow-soft">
        <h2 className="text-2xl">Share your brief</h2>
        <p className="mb-5 mt-1 text-sm text-muted-foreground">We reply within two working days.</p>
        <LeadForm kind="corporate" cta="Send my brief" contactLabel="Work email or phone" withDetails="Occasion, number of gifts, budget per gift, and when you need them" />
      </div>
    </main>
  );
}
