import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { makersQuery } from "@/lib/queries";
import { MakerCard } from "@/components/maker-card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/makers/")({
  head: () => ({
    meta: [
      { title: "Meet the makers — Baksa Tales" },
      { name: "description", content: "The independent Indian studios behind every Baksa Tales gift, from soy wax florals to Ayurvedic skincare." },
      { property: "og:title", content: "Meet the makers — Baksa Tales" },
      { property: "og:description", content: "The independent Indian studios behind every Baksa Tales gift." },
    ],
  }),
  component: Makers,
});

function Makers() {
  const { data } = useQuery(makersQuery);
  const founding = (data ?? []).filter((m) => m.is_founding);
  const rest = (data ?? []).filter((m) => !m.is_founding);
  return (
    <main className="mx-auto max-w-6xl px-5 py-16">
      <p className="eyebrow">The people behind the gifts</p>
      <h1 className="mt-3 max-w-2xl text-5xl md:text-6xl">Every piece has a <em className="text-primary">name</em> behind it.</h1>
      <h2 className="mt-14 text-3xl">Founding makers</h2>
      <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{founding.map((m) => <MakerCard key={m.id} m={m} />)}</div>
      {rest.length > 0 && (
        <>
          <h2 className="mt-16 text-3xl">New to the circle</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{rest.map((m) => <MakerCard key={m.id} m={m} />)}</div>
        </>
      )}
      <div className="mt-20 rounded-3xl bg-band p-10 text-teal-foreground md:flex md:items-center md:justify-between">
        <div><p className="text-sm text-gold-light">Are you a maker?</p><h2 className="mt-1 text-3xl">Sell with Baksa Tales</h2><p className="mt-2 max-w-xl opacity-85">We bring your story to people who value handmade work, and help you grow with simple tools for pricing, orders and payouts. There’s no listing fee.</p></div>
        <div className="mt-6 flex flex-wrap gap-3 md:mt-0"><Button asChild size="lg"><Link to="/sell">Tell us about your work</Link></Button><Button asChild size="lg" variant="outline" className="bg-transparent text-teal-foreground"><Link to="/studio">Open my studio</Link></Button></div>
      </div>
    </main>
  );
}
