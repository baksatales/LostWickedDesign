import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Check, ShieldCheck, HandHeart } from "lucide-react";
import { productImage, RECIP, OCC, FEEL } from "@/lib/catalog";
import { productQuery } from "@/lib/queries";
import { formatINR } from "@/lib/pricing";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/product/$id")({
  head: () => ({
    meta: [
      { title: "Handmade gift — Baksa Tales" },
      { name: "description", content: "A handmade piece from an independent Baksa Tales maker." },
      { property: "og:title", content: "Handmade gift — Baksa Tales" },
      { property: "og:description", content: "A handmade piece from an independent Baksa Tales maker." },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const { data: p, isLoading } = useQuery(productQuery(id));
  const { add } = useCart();
  const navigate = useNavigate();
  if (isLoading) return <main className="mx-auto max-w-6xl px-5 py-24 text-muted-foreground">Loading…</main>;
  if (!p) return <main className="mx-auto max-w-6xl px-5 py-24">This gift isn’t available. <Link to="/shop" className="text-primary underline">See all gifts</Link></main>;
  const img = productImage(p);
  const tags = [...p.occasions.map((o) => OCC[o as keyof typeof OCC]), ...p.recipients.map((r) => RECIP[r as keyof typeof RECIP])].filter(Boolean);
  const buyable = p.stock > 0 && p.status === "approved";
  const addIt = () => add({ productId: p.id, name: p.name, price: p.price_inr, imageUrl: img, maker: p.maker_name });
  const ctas = (
    <>
      <Button variant="cta" size="lg" className="flex-1" disabled={!buyable} onClick={() => { addIt(); navigate({ to: "/checkout" }); }}>Buy now</Button>
      <Button variant="outline" size="lg" className="flex-1" disabled={!buyable} onClick={() => { addIt(); toast.success("Added to your bag"); }}>Add to bag</Button>
    </>
  );
  return (
    <main className="mx-auto grid max-w-6xl gap-12 px-5 pb-32 pt-10 md:grid-cols-2 md:pb-14">
      <img src={img} alt={p.name} className="aspect-square w-full rounded-3xl border object-cover shadow-soft" />
      <div className="animate-rise">
        <Link to="/makers/$id" params={{ id: p.maker_id }} className="eyebrow hover:text-primary">by {p.maker_name} →</Link>
        <h1 className="mt-3 text-5xl">{p.name}</h1>
        <p className="mt-4 text-3xl font-bold">{formatINR(p.price_inr)}</p>
        {p.status !== "approved" && <p className="mt-3 inline-block rounded-full bg-accent px-3 py-1 text-xs font-semibold">Not yet live: {p.status}</p>}
        <p className={`mt-3 text-sm font-semibold ${p.stock > 0 && p.stock <= 3 ? "text-warning" : "text-success"}`}>
          {p.stock > 0 ? (p.stock <= 3 ? `Only ${p.stock} left — each one is made by hand` : "In stock") : "Sold out"}
        </p>
        <div className="mt-6 hidden gap-3 md:flex">{ctas}</div>
        <p className="mt-8 text-lg leading-relaxed">{p.description}</p>
        {p.feelings.length > 0 && (
          <ul className="mt-6 space-y-2">{p.feelings.map((f) => <li key={f} className="flex gap-2"><Check className="mt-0.5 h-5 w-5 text-primary" />{FEEL[f as keyof typeof FEEL]}</li>)}</ul>
        )}
        <div className="mt-6 flex flex-wrap gap-2">{tags.map((t) => <span key={t} className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold">{t}</span>)}</div>
        <div className="mt-8 grid gap-3 rounded-2xl bg-secondary/60 p-5 text-sm sm:grid-cols-2">
          <p className="flex gap-2"><HandHeart className="h-5 w-5 text-primary" /> Made by hand by {p.maker_name}</p>
          <p className="flex gap-2"><ShieldCheck className="h-5 w-5 text-primary" /> Reviewed by Baksa Tales</p>
        </div>
      </div>
      {/* Thumb-zone sticky CTA on phones (Fitts's law). */}
      <div className="fixed inset-x-0 bottom-0 z-30 flex gap-3 border-t bg-background/95 p-4 backdrop-blur md:hidden">{ctas}</div>
    </main>
  );
}
