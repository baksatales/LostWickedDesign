import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { formatINR } from "@/lib/pricing";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/classes")({
  head: () => ({ meta: [{ title: "My classes — Baksa Tales" }, { name: "description", content: "Classes and workshops you’ve booked." }, { property: "og:title", content: "My classes — Baksa Tales" }, { property: "og:description", content: "Classes and workshops you’ve booked." }] }),
  component: MyClasses,
});

function MyClasses() {
  const { user } = useAuth();
  const { data } = useQuery({
    queryKey: ["my-classes", user?.id], enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("course_enrolments").select("*, courses(*)").eq("shopper_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error; return data;
    },
  });
  return (
    <main className="mx-auto max-w-4xl px-5 py-14">
      <p className="eyebrow">Makers’ Academy</p>
      <h1 className="mt-2 text-5xl">My classes</h1>
      <div className="mt-8 space-y-4">
        {(data ?? []).map((e) => (
          <article key={e.id} className="rounded-2xl border bg-card p-6">
            <p className="eyebrow">{e.courses?.format === "live" ? "Live workshop" : "Recorded class"}</p>
            <h2 className="mt-1 text-2xl">{e.courses?.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{e.courses?.schedule} · paid {formatINR(Number(e.price_inr))} · {new Date(e.created_at).toLocaleDateString("en-IN")}</p>
            {e.courses?.meeting_link
              ? <Button asChild className="mt-4"><a href={e.courses.meeting_link} target="_blank" rel="noreferrer">{e.courses.format === "live" ? "Join the workshop" : "Watch the class"}</a></Button>
              : <p className="mt-4 text-sm text-muted-foreground">We’ll add the {e.courses?.format === "live" ? "joining link" : "lessons"} here before it starts.</p>}
          </article>
        ))}
        {!data?.length && <div className="rounded-2xl border border-dashed p-10 text-center"><p className="text-muted-foreground">You haven’t booked a class yet.</p><Button asChild variant="cta" className="mt-4"><Link to="/academy">Browse the Academy</Link></Button></div>}
      </div>
    </main>
  );
}
