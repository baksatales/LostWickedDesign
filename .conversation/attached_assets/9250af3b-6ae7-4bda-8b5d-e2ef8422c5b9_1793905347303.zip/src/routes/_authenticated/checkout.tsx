import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { CreditCard, Lock } from "lucide-react";
import { useCart } from "@/hooks/use-cart";
import { placeOrder } from "@/lib/checkout.functions";
import { formatINR } from "@/lib/pricing";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/checkout")({
  head: () => ({ meta: [{ title: "Checkout — Baksa Tales" }, { name: "description", content: "Pay for your handmade gifts." }, { property: "og:title", content: "Checkout — Baksa Tales" }, { property: "og:description", content: "Pay for your handmade gifts." }] }),
  component: Checkout,
});

function Checkout() {
  const { lines, quiz, clear } = useCart();
  const pay = useServerFn(placeOrder);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [f, setF] = useState({ recipientName: "", address: "", giftNote: "", number: "4242 4242 4242 4242", expiry: "12/30", cvc: "123", cardName: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const total = lines.reduce((a, l) => a + l.price * l.quantity, 0);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  if (!lines.length) return <main className="mx-auto max-w-3xl px-5 py-24">Your bag is empty. <Link to="/finder" className="text-primary underline">Find a gift</Link></main>;

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr(null);
    try {
      const r = await pay({ data: {
        items: lines.map((l) => ({ productId: l.productId, quantity: l.quantity })),
        card: { number: f.number, expiry: f.expiry, cvc: f.cvc, name: f.cardName },
        recipientName: f.recipientName, address: f.address, giftNote: f.giftNote || undefined, quiz: quiz ?? undefined,
      } });
      if (!r.ok) { setErr(r.error); return; }
      clear();
      qc.invalidateQueries({ queryKey: ["products"] });
      toast.success("Payment received");
      navigate({ to: "/orders", search: { placed: r.orderId } });
    } catch (e2) { setErr(e2 instanceof Error ? e2.message : "Payment failed"); }
    finally { setBusy(false); }
  }

  return (
    <main className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-[1fr_360px]">
      <form onSubmit={submit} className="space-y-8">
        <h1 className="text-5xl">Checkout</h1>
        <section className="space-y-4 rounded-lg border bg-card p-6">
          <h2 className="text-2xl">Who’s receiving it?</h2>
          <div className="space-y-1.5"><Label htmlFor="rn">Recipient’s name</Label><Input id="rn" required minLength={2} value={f.recipientName} onChange={set("recipientName")} /></div>
          <div className="space-y-1.5"><Label htmlFor="ad">Delivery address</Label><Textarea id="ad" required minLength={8} value={f.address} onChange={set("address")} placeholder="House, street, city, PIN code" /></div>
          <div className="space-y-1.5"><Label htmlFor="gn">Gift note (optional)</Label><Textarea id="gn" maxLength={300} value={f.giftNote} onChange={set("giftNote")} /></div>
        </section>
        <section className="space-y-4 rounded-lg border bg-card p-6">
          <div className="flex items-center justify-between"><h2 className="text-2xl">Payment</h2><span className="rounded-full bg-accent px-3 py-1 font-slab text-xs text-accent-foreground">Test mode</span></div>
          <p className="text-sm text-muted-foreground">Use 4242 4242 4242 4242 to succeed, or 4000 0000 0000 0002 to see a decline. Any future expiry, any 3-digit code.</p>
          <div className="space-y-1.5"><Label htmlFor="cn">Card number</Label>
            <div className="relative"><CreditCard className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input id="cn" className="pl-9 font-slab" inputMode="numeric" required value={f.number} onChange={set("number")} /></div></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label htmlFor="ex">Expiry (MM/YY)</Label><Input id="ex" className="font-slab" required value={f.expiry} onChange={set("expiry")} /></div>
            <div className="space-y-1.5"><Label htmlFor="cv">Security code</Label><Input id="cv" className="font-slab" inputMode="numeric" required value={f.cvc} onChange={set("cvc")} /></div>
          </div>
          <div className="space-y-1.5"><Label htmlFor="nm">Name on card</Label><Input id="nm" required value={f.cardName} onChange={set("cardName")} /></div>
          {err && <p role="alert" className="rounded-md bg-destructive/10 p-3 text-destructive">{err}</p>}
          <Button type="submit" size="lg" className="w-full font-slab" disabled={busy}><Lock className="mr-1 h-4 w-4" />{busy ? "Processing…" : `Pay ${formatINR(total)}`}</Button>
        </section>
      </form>
      <aside className="h-fit space-y-3 rounded-lg border bg-card p-6 md:sticky md:top-24">
        <h2 className="font-slab text-sm">Order summary</h2>
        {lines.map((l) => (
          <div key={l.productId} className="flex items-center gap-3 border-b pb-3">
            <img src={l.imageUrl} alt="" className="h-14 w-14 rounded object-cover" />
            <div className="flex-1"><p>{l.name}</p><p className="text-sm text-muted-foreground">× {l.quantity}</p></div>
            <span className="font-slab text-sm">{formatINR(l.price * l.quantity)}</span>
          </div>
        ))}
        <div className="flex justify-between pt-2 text-xl"><span>Total</span><span className="font-slab">{formatINR(total)}</span></div>
      </aside>
    </main>
  );
}
