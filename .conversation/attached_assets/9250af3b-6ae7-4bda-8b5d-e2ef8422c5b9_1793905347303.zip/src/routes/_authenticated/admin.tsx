import { PagesManager } from "@/components/site-pages";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { productImage, RECIP, OCC, FEEL, type Product } from "@/lib/catalog";
import { formatINR } from "@/lib/pricing";
import { settingsQuery } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusPill, StatTile } from "@/components/dashboard";
import { ReturnsDesk } from "@/components/returns";
import { BadgeManager, AcademyAdmin, ContentEditor, LeadsTable } from "@/components/admin-extras";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — Baksa Tales" }, { name: "description", content: "Review products and track orders and commission." }, { property: "og:title", content: "Admin — Baksa Tales" }, { property: "og:description", content: "Review products and track orders and commission." }] }),
  component: Admin,
});

function Admin() {
  const { roles, loading, refreshRoles } = useAuth();
  const adminExists = useQuery({ queryKey: ["admin-exists"], queryFn: async () => (await supabase.rpc("admin_exists")).data ?? true });
  if (loading) return <main className="mx-auto max-w-6xl px-5 py-24 text-muted-foreground">Loading…</main>;
  if (!roles.includes("admin")) {
    return (
      <main className="mx-auto max-w-xl px-5 py-24 text-center">
        <h1 className="text-4xl">Administrators only</h1>
        {adminExists.data === false ? (
          <>
            <p className="mt-3 text-muted-foreground">This marketplace has no administrator yet. The first person to claim it becomes the administrator.</p>
            <Button className="mt-6 font-slab" onClick={async () => {
              const { data } = await supabase.rpc("claim_admin");
              if (data) { toast.success("You’re now the administrator"); await refreshRoles(); } else toast.error("Someone has already claimed it.");
              adminExists.refetch();
            }}>Become administrator</Button>
          </>
        ) : <p className="mt-3 text-muted-foreground">Your account doesn’t have access to this page.</p>}
      </main>
    );
  }
  return <AdminDashboard />;
}

function AdminDashboard() {
  const qc = useQueryClient();
  const products = useQuery({
    queryKey: ["admin-products"],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false });
      if (error) throw error; return data as Product[];
    },
  });
  const orders = useQuery({
    queryKey: ["admin-orders"],
    queryFn: async () => {
      const { data, error } = await supabase.from("orders").select("*, order_items(*)").order("created_at", { ascending: false });
      if (error) throw error; return data;
    },
  });
  const pending = (products.data ?? []).filter((p) => p.status === "pending");
  const o = orders.data ?? [];
  const tot = (k: "subtotal_inr" | "commission_inr" | "gateway_fee_inr" | "seller_earnings_inr") => o.reduce((a, x) => a + Number(x[k]), 0);

  async function review(p: Product, status: "approved" | "rejected", note?: string) {
    const { error } = await supabase.from("products").update({ status, review_note: note ?? null }).eq("id", p.id);
    if (error) { toast.error(error.message); return; }
    toast.success(status === "approved" ? `${p.name} is now live` : `${p.name} sent back to the maker`);
    qc.invalidateQueries({ queryKey: ["admin-products"] });
    qc.invalidateQueries({ queryKey: ["products"] });
  }

  return (
    <main className="mx-auto max-w-6xl px-5 py-14">
      <p className="eyebrow">Marketplace</p>
      <h1 className="mt-2 text-5xl">Admin</h1>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatTile label="Gross sales" value={formatINR(tot("subtotal_inr"))} />
        <StatTile label="Commission earned" value={formatINR(tot("commission_inr"))} accent />
        <StatTile label="Payment fees" value={formatINR(tot("gateway_fee_inr"))} />
        <StatTile label="Owed to makers" value={formatINR(tot("seller_earnings_inr"))} />
      </div>

      <Tabs defaultValue="review" className="mt-10">
        <TabsList className="h-auto flex-wrap">
          <TabsTrigger value="review">Review queue ({pending.length})</TabsTrigger>
          <TabsTrigger value="orders">Orders ({o.length})</TabsTrigger>
          <TabsTrigger value="returns">Returns</TabsTrigger>
          <TabsTrigger value="catalog">Catalogue</TabsTrigger>
          <TabsTrigger value="badges">Badges</TabsTrigger>
          <TabsTrigger value="academy">Academy</TabsTrigger>
          <TabsTrigger value="content">Home page</TabsTrigger>
          <TabsTrigger value="pages">Pages &amp; blog</TabsTrigger>
          <TabsTrigger value="leads">Sign-ups</TabsTrigger>
          <TabsTrigger value="settings">Fees</TabsTrigger>
        </TabsList>

        <TabsContent value="review" className="mt-6 space-y-4">
          {!pending.length && <p className="rounded-lg border border-dashed p-10 text-center text-muted-foreground">Nothing waiting for review.</p>}
          {pending.map((p) => <ReviewCard key={p.id} p={p} onReview={review} />)}
        </TabsContent>

        <TabsContent value="orders" className="mt-6">
          <div className="overflow-x-auto rounded-lg border bg-card">
            <table className="w-full text-left text-sm">
              <thead className="font-slab text-xs text-muted-foreground"><tr><th className="p-3">Order</th><th className="p-3">Items</th><th className="p-3">Paid</th><th className="p-3">Commission</th><th className="p-3">Fee</th><th className="p-3">Makers earn</th><th className="p-3">Payment</th></tr></thead>
              <tbody>
                {o.map((x) => (
                  <tr key={x.id} className="border-t align-top">
                    <td className="p-3"><span className="font-slab">#{x.id.slice(0, 8).toUpperCase()}</span><br /><span className="text-muted-foreground">{new Date(x.created_at).toLocaleDateString("en-IN")}</span></td>
                    <td className="p-3">{x.order_items.map((i) => <div key={i.id}>{i.product_name} × {i.quantity}</div>)}</td>
                    <td className="p-3">{formatINR(Number(x.subtotal_inr))}</td>
                    <td className="p-3">{formatINR(Number(x.commission_inr))} <span className="text-muted-foreground">({Number(x.commission_pct)}%)</span></td>
                    <td className="p-3">{formatINR(Number(x.gateway_fee_inr))}</td>
                    <td className="p-3 font-slab text-success">{formatINR(Number(x.seller_earnings_inr))}</td>
                    <td className="p-3 text-xs text-muted-foreground">{x.payment_ref}<br />•••• {x.card_last4}</td>
                  </tr>
                ))}
                {!o.length && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No orders yet.</td></tr>}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="catalog" className="mt-6">
          <ul className="grid gap-3 md:grid-cols-2">
            {(products.data ?? []).map((p) => (
              <li key={p.id} className="flex items-center gap-3 rounded-lg border bg-card p-3">
                <img src={productImage(p)} alt="" className="h-14 w-14 rounded object-cover" />
                <div className="flex-1"><p>{p.name}</p><p className="text-sm text-muted-foreground">{p.maker_name} · {formatINR(p.price_inr)} · {p.stock} left</p></div>
                <StatusPill status={p.status} />
                {p.status === "approved" && <Button size="sm" variant="ghost" onClick={() => review(p, "rejected", "Paused by admin")}>Unlist</Button>}
              </li>
            ))}
          </ul>
        </TabsContent>

        <TabsContent value="returns" className="-mt-8"><ReturnsDesk title="All returns" /></TabsContent>
        <TabsContent value="settings" className="mt-6"><FeeSettings /></TabsContent>
        <TabsContent value="badges" className="mt-6"><BadgeManager /></TabsContent>
        <TabsContent value="academy" className="mt-6"><AcademyAdmin /></TabsContent>
        <TabsContent value="content" className="mt-6"><ContentEditor /></TabsContent>
        <TabsContent value="pages" className="mt-6"><PagesManager /></TabsContent>
        <TabsContent value="leads" className="mt-6"><LeadsTable /></TabsContent>
      </Tabs>
    </main>
  );
}

function ReviewCard({ p, onReview }: { p: Product; onReview: (p: Product, s: "approved" | "rejected", note?: string) => void }) {
  const [note, setNote] = useState("");
  return (
    <article className="grid gap-5 rounded-lg border bg-card p-5 md:grid-cols-[140px_1fr]">
      <img src={productImage(p)} alt={p.name} className="aspect-square w-full rounded object-cover" />
      <div>
        <div className="flex flex-wrap items-baseline justify-between gap-2"><h3 className="text-2xl">{p.name}</h3><span className="font-slab">{formatINR(p.price_inr)} · {p.stock} in stock</span></div>
        <p className="eyebrow mt-1">{p.maker_name}</p>
        <p className="mt-3">{p.description}</p>
        <p className="mt-3 text-sm text-muted-foreground">
          {[...p.recipients.map((r) => RECIP[r as keyof typeof RECIP]), ...p.occasions.map((x) => OCC[x as keyof typeof OCC]), ...p.feelings.map((x) => FEEL[x as keyof typeof FEEL])].filter(Boolean).join(" · ")}
        </p>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <Button className="font-slab" onClick={() => onReview(p, "approved")}>Approve</Button>
          <Input placeholder="What should the maker change?" value={note} onChange={(e) => setNote(e.target.value)} className="max-w-xs" />
          <Button variant="outline" className="font-slab" onClick={() => onReview(p, "rejected", note || "Please revise and resubmit")}>Send back</Button>
        </div>
      </div>
    </article>
  );
}

function FeeSettings() {
  const qc = useQueryClient();
  const { data } = useQuery(settingsQuery);
  const [c, setC] = useState<string>(""); const [g, setG] = useState<string>("");
  if (!data) return null;
  return (
    <form className="max-w-md space-y-4 rounded-lg border bg-card p-6" onSubmit={async (e) => {
      e.preventDefault();
      const { error } = await supabase.from("platform_settings").update({ commission_pct: Number(c || data.commissionPct), gateway_fee_pct: Number(g || data.gatewayFeePct), updated_at: new Date().toISOString() }).eq("id", 1);
      if (error) toast.error(error.message); else { toast.success("Fees updated for new orders"); qc.invalidateQueries({ queryKey: ["settings"] }); }
    }}>
      <p className="text-muted-foreground">Applies to new orders only. Past orders keep the rate they were placed at.</p>
      <div className="space-y-1.5"><Label htmlFor="cp">Commission (%)</Label><Input id="cp" type="number" step="0.5" min={0} max={50} placeholder={String(data.commissionPct)} value={c} onChange={(e) => setC(e.target.value)} /></div>
      <div className="space-y-1.5"><Label htmlFor="gp">Payment fee (%)</Label><Input id="gp" type="number" step="0.1" min={0} max={10} placeholder={String(data.gatewayFeePct)} value={g} onChange={(e) => setG(e.target.value)} /></div>
      <Button type="submit" className="font-slab">Save</Button>
    </form>
  );
}
