import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { CheckCircle2, Package, GraduationCap, RotateCcw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { formatINR } from "@/lib/pricing";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { RETURN_LABEL, RETURN_WINDOW_DAYS } from "@/components/returns";

export const Route = createFileRoute("/_authenticated/orders")({
  validateSearch: z.object({ placed: z.string().optional() }),
  head: () => ({ meta: [{ title: "My orders & returns — Baksa Tales" }, { name: "description", content: "Your Baksa Tales orders, classes and returns in one place." }, { property: "og:title", content: "My orders & returns — Baksa Tales" }, { property: "og:description", content: "Your Baksa Tales orders, classes and returns in one place." }] }),
  component: Orders,
});

const STEPS = ["Paid", "Being made", "Shipped", "Delivered"];
const STEP_KEYS = ["paid", "making", "shipped", "delivered"];

function Orders() {
  const { placed } = Route.useSearch();
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const { data, isLoading } = useQuery({
    queryKey: ["my-orders", user?.id], enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("orders").select("*, order_items(*)").eq("shopper_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error; return data;
    },
  });
  const returns = useQuery({
    queryKey: ["my-returns", user?.id], enabled: !!user,
    queryFn: async () => (await supabase.from("return_requests").select("*").eq("shopper_id", user!.id)).data ?? [],
  });
  const classes = useQuery({
    queryKey: ["my-class-count", user?.id], enabled: !!user,
    queryFn: async () => (await supabase.from("course_enrolments").select("id", { count: "exact", head: true }).eq("shopper_id", user!.id)).count ?? 0,
  });
  const byItem = new Map((returns.data ?? []).map((r) => [r.order_item_id, r]));
  const orders = data ?? [];
  const spent = orders.reduce((a, o) => a + Number(o.subtotal_inr), 0);

  async function submitReturn(itemId: string) {
    const { error } = await supabase.rpc("request_return", { _order_item_id: itemId, _reason: reason });
    if (error) { toast.error(error.message); return; }
    toast.success("Return requested. The maker will reply here.");
    setOpen(null); setReason("");
    qc.invalidateQueries({ queryKey: ["my-returns"] });
  }

  return (
    <main className="mx-auto max-w-5xl px-5 py-14">
      {placed && (
        <div className="mb-10 flex gap-4 rounded-lg bg-band p-6 text-teal-foreground animate-rise">
          <CheckCircle2 className="h-8 w-8 shrink-0" />
          <div><h2 className="text-3xl">Thank you. Your order is in.</h2><p className="mt-1 opacity-90">The maker has been told and will pack it with care.</p></div>
        </div>
      )}
      <p className="eyebrow">Your account</p>
      <h1 className="mt-2 text-5xl">My orders &amp; returns</h1>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <div className="rounded-lg border bg-card p-5"><Package className="h-5 w-5 text-gold" /><p className="mt-2 text-3xl font-serif">{orders.length}</p><p className="text-sm text-muted-foreground">Orders · {formatINR(spent)}</p></div>
        <Link to="/classes" className="rounded-lg border bg-card p-5 hover:border-primary"><GraduationCap className="h-5 w-5 text-gold" /><p className="mt-2 text-3xl font-serif">{classes.data ?? 0}</p><p className="text-sm text-muted-foreground">Classes booked →</p></Link>
        <div className="rounded-lg border bg-card p-5"><RotateCcw className="h-5 w-5 text-gold" /><p className="mt-2 text-3xl font-serif">{returns.data?.length ?? 0}</p><p className="text-sm text-muted-foreground">Returns · {RETURN_WINDOW_DAYS}-day window</p></div>
      </div>

      {isLoading ? <p className="mt-8 text-muted-foreground">Loading…</p> : !orders.length ? (
        <div className="mt-8 rounded-lg border border-dashed p-10 text-center text-muted-foreground">No orders yet. <Link to="/finder" className="font-semibold text-primary">Find a gift →</Link></div>
      ) : (
        <div className="mt-10 space-y-5">
          {orders.map((o) => {
            const days = (Date.now() - new Date(o.created_at).getTime()) / 864e5;
            const canReturn = days <= RETURN_WINDOW_DAYS;
            return (
              <article key={o.id} className={`rounded-lg border bg-card p-6 ${o.id === placed ? "ring-2 ring-primary" : ""}`}>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <p className="font-slab text-sm">Order #{o.id.slice(0, 8).toUpperCase()}</p>
                  <p className="text-sm text-muted-foreground">{new Date(o.created_at).toLocaleString("en-IN")}</p>
                </div>
                {(() => { const at = Math.min(...o.order_items.map((i) => STEP_KEYS.indexOf(i.fulfilment))); return (
                <ol className="mt-4 grid grid-cols-4 gap-2 text-xs" aria-label="Order progress">
                  {STEPS.map((s, i) => <li key={s} className={`border-t-4 pt-2 transition-colors ${i <= at ? "border-primary font-semibold" : "border-border text-muted-foreground"}`}>{s}</li>)}
                </ol>); })()}
                <ul className="mt-4 divide-y">
                  {o.order_items.map((i) => {
                    const r = byItem.get(i.id);
                    return (
                      <li key={i.id} className="py-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span>{i.product_name} × {i.quantity} <span className="ml-2 text-xs text-muted-foreground">· {STEPS[STEP_KEYS.indexOf(i.fulfilment)]}</span></span>
                          <span className="flex items-center gap-3">
                            {r ? <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold">{RETURN_LABEL[r.status]}</span>
                              : canReturn && <button onClick={() => { setOpen(i.id); setReason(""); }} className="text-xs font-semibold text-primary hover:underline">Return this</button>}
                            <span className="font-slab text-sm">{formatINR(Number(i.line_total_inr))}</span>
                          </span>
                        </div>
                        {r?.maker_note && <p className="mt-1 text-sm text-muted-foreground">Maker: {r.maker_note}</p>}
                        {open === i.id && (
                          <div className="mt-3 space-y-2 rounded-lg bg-secondary p-4">
                            <Textarea placeholder="What went wrong? A photo-worthy description helps the maker." value={reason} onChange={(e) => setReason(e.target.value)} maxLength={600} />
                            <div className="flex gap-2"><Button size="sm" disabled={reason.trim().length < 3} onClick={() => submitReturn(i.id)}>Send request</Button><Button size="sm" variant="ghost" onClick={() => setOpen(null)}>Cancel</Button></div>
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ul>
                <div className="mt-3 flex flex-wrap justify-between gap-2 border-t pt-3 text-sm text-muted-foreground">
                  <span>For {o.recipient_name} · card ending {o.card_last4}{!canReturn && " · return window closed"}</span>
                  <span className="font-slab text-base text-foreground">{formatINR(Number(o.subtotal_inr))}</span>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </main>
  );
}
