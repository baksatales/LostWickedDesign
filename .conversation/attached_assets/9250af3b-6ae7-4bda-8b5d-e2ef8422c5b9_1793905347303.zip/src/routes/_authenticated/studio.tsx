import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { ImagePlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { RECIP, OCC, FEEL, productImage, type Product } from "@/lib/catalog";
import { formatINR, splitLine } from "@/lib/pricing";
import { settingsQuery } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { StatusPill, StatTile } from "@/components/dashboard";
import { cn } from "@/lib/utils";
import { MakerProfileForm } from "@/components/maker-profile-form";
import { GrowthStudio } from "@/components/growth-studio";
import { CourseProposals } from "@/components/course-proposals";
import { MakerBadges } from "@/components/badge-pill";
import { ReturnsDesk } from "@/components/returns";

export const Route = createFileRoute("/_authenticated/studio")({
  head: () => ({ meta: [{ title: "My studio — Baksa Tales" }, { name: "description", content: "List products and see your earnings." }, { property: "og:title", content: "My studio — Baksa Tales" }, { property: "og:description", content: "List products and see your earnings." }] }),
  component: Studio,
});

function Chips({ label, opts, value, onChange }: { label: string; opts: Record<string, string>; value: string[]; onChange: (v: string[]) => void }) {
  return (
    <fieldset className="space-y-2">
      <legend className="text-sm font-medium">{label}</legend>
      <div className="flex flex-wrap gap-2">
        {Object.entries(opts).map(([k, v]) => {
          const on = value.includes(k);
          return <button type="button" key={k} aria-pressed={on} onClick={() => onChange(on ? value.filter((x) => x !== k) : [...value, k])}
            className={cn("rounded-full border px-3 py-1.5 text-sm transition-colors", on ? "border-teal bg-teal text-teal-foreground" : "bg-card hover:border-teal")}>{v}</button>;
        })}
      </div>
    </fieldset>
  );
}

function Studio() {
  const { user, roles, loading } = useAuth();
  const qc = useQueryClient();
  const empty = { name: "", description: "", price: "", stock: "5", recipients: [] as string[], occasions: [] as string[], feelings: [] as string[] };
  const [f, setF] = useState(empty);
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  const mine = useQuery({
    queryKey: ["studio-products", user?.id], enabled: !!user && roles.includes("maker"),
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").eq("maker_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error; return data as Product[];
    },
  });
  const sales = useQuery({
    queryKey: ["studio-sales", user?.id], enabled: !!user && roles.includes("maker"),
    queryFn: async () => {
      const { data, error } = await supabase.from("order_items").select("*").eq("maker_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error; return data;
    },
  });
  const fees = useQuery(settingsQuery);
  const profile = useQuery({
    queryKey: ["profile", user?.id], enabled: !!user,
    queryFn: async () => (await supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle()).data,
  });

  if (loading) return <main className="mx-auto max-w-6xl px-5 py-24 text-muted-foreground">Loading…</main>;
  if (!roles.includes("maker")) return (
    <main className="mx-auto max-w-xl px-5 py-24 text-center">
      <h1 className="text-4xl">This space is for makers</h1>
      <p className="mt-3 text-muted-foreground">Your account is a shopper account. Create a maker account to list products.</p>
      <Button asChild className="mt-6 font-slab"><Link to="/">Back to gifts</Link></Button>
    </main>
  );

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!f.occasions.length && !f.feelings.length) { toast.error("Pick at least one occasion or feeling so shoppers can find it."); return; }
    setBusy(true);
    try {
      let image_url: string | null = null;
      if (file) {
        const path = `${user!.id}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "")}`;
        const up = await supabase.storage.from("product-images").upload(path, file, { contentType: file.type });
        if (up.error) throw up.error;
        const signed = await supabase.storage.from("product-images").createSignedUrl(path, 60 * 60 * 24 * 365 * 5);
        if (signed.error) throw signed.error;
        image_url = signed.data.signedUrl;
      }
      const { error } = await supabase.from("products").insert({
        maker_id: user!.id, maker_name: profile.data?.studio_name || profile.data?.display_name || "Independent maker",
        name: f.name, description: f.description, price_inr: Math.round(Number(f.price)), stock: Math.max(0, Math.round(Number(f.stock))),
        image_url, image_key: image_url ? null : "t-lotuspond", recipients: f.recipients, occasions: f.occasions, feelings: f.feelings,
      });
      if (error) throw error;
      toast.success("Sent for review. We’ll let you know once it’s live.");
      setF(empty); setFile(null);
      qc.invalidateQueries({ queryKey: ["studio-products"] });
    } catch (err) { toast.error(err instanceof Error ? err.message : "Could not submit"); }
    finally { setBusy(false); }
  }

  const s = sales.data ?? [];
  const sum = (k: "line_total_inr" | "commission_inr" | "gateway_fee_inr" | "seller_earnings_inr") => s.reduce((a, x) => a + Number(x[k]), 0);

  return (
    <main className="mx-auto max-w-6xl px-5 py-14">
      <p className="eyebrow">{profile.data?.studio_name || "Your studio"}</p>
      <h1 className="mt-2 text-5xl">My studio</h1>
      {user && <MakerBadges makerId={user.id} className="mt-3" />}
      {user && <MakerProfileForm userId={user.id} />}

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatTile label="Sales" value={formatINR(sum("line_total_inr"))} />
        <StatTile label="Platform commission" value={`− ${formatINR(sum("commission_inr"))}`} />
        <StatTile label="Payment fees" value={`− ${formatINR(sum("gateway_fee_inr"))}`} />
        <StatTile label="Your earnings" value={formatINR(sum("seller_earnings_inr"))} accent />
      </div>

      <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.1fr]">
        <form onSubmit={submit} className="space-y-5 rounded-lg border bg-card p-6">
          <h2 className="text-3xl">List a new piece</h2>
          <div className="space-y-1.5"><Label htmlFor="pn">Name</Label><Input id="pn" required minLength={2} maxLength={120} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="pd">The story behind it</Label><Textarea id="pd" required value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label htmlFor="pp">Price (₹)</Label><Input id="pp" type="number" min={1} required value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></div>
            <div className="space-y-1.5"><Label htmlFor="ps">In stock</Label><Input id="ps" type="number" min={0} required value={f.stock} onChange={(e) => setF({ ...f, stock: e.target.value })} /></div>
          </div>
          <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-dashed p-4 hover:border-primary">
            <ImagePlus className="h-5 w-5 text-muted-foreground" />
            <span className="text-sm">{file ? file.name : "Add a photo (JPG or PNG, up to 5 MB)"}</span>
            <input type="file" accept="image/*" className="sr-only" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          </label>
          <Chips label="Who is it for?" opts={RECIP} value={f.recipients} onChange={(v) => setF({ ...f, recipients: v })} />
          <Chips label="Occasions" opts={OCC} value={f.occasions} onChange={(v) => setF({ ...f, occasions: v })} />
          <Chips label="What does it do?" opts={FEEL} value={f.feelings} onChange={(v) => setF({ ...f, feelings: v })} />
          {fees.data && Number(f.price) > 0 && <p className="text-sm text-muted-foreground">On each sale at {formatINR(Number(f.price))}, you keep {formatINR(splitLine({ unitPrice: Number(f.price), quantity: 1 }, fees.data).sellerEarnings)} after {fees.data.commissionPct}% commission and {fees.data.gatewayFeePct}% payment fee.</p>}
          <Button type="submit" className="w-full font-slab" disabled={busy}>{busy ? "Submitting…" : "Submit for review"}</Button>
        </form>

        <div className="space-y-10">
          <section>
            <h2 className="text-3xl">Your pieces</h2>
            <ul className="mt-4 space-y-3">
              {(mine.data ?? []).map((p) => (
                <li key={p.id} className="flex items-center gap-4 rounded-lg border bg-card p-3">
                  <img src={productImage(p)} alt="" className="h-16 w-16 rounded object-cover" />
                  <div className="flex-1">
                    <p className="text-lg">{p.name}</p>
                    <p className="text-sm text-muted-foreground">{formatINR(p.price_inr)} · {p.stock} in stock</p>
                    {p.review_note && <p className="text-sm text-destructive">Reviewer: {p.review_note}</p>}
                  </div>
                  <StatusPill status={p.status} />
                </li>
              ))}
              {!mine.data?.length && <li className="rounded-lg border border-dashed p-8 text-center text-muted-foreground">Nothing listed yet.</li>}
            </ul>
          </section>
          <section>
            <h2 className="text-3xl">Sales</h2>
            <div className="mt-4 overflow-x-auto rounded-lg border bg-card">
              <table className="w-full text-left text-sm">
                <thead className="font-slab text-xs text-muted-foreground"><tr><th className="p-3">Piece</th><th className="p-3">Sale</th><th className="p-3">Commission</th><th className="p-3">Fee</th><th className="p-3">You earn</th><th className="p-3">Progress</th></tr></thead>
                <tbody>
                  {s.map((i) => (
                    <tr key={i.id} className="border-t"><td className="p-3">{i.product_name} × {i.quantity}</td><td className="p-3">{formatINR(Number(i.line_total_inr))}</td><td className="p-3">{formatINR(Number(i.commission_inr))}</td><td className="p-3">{formatINR(Number(i.gateway_fee_inr))}</td><td className="p-3 font-slab text-success">{formatINR(Number(i.seller_earnings_inr))}</td><td className="p-3"><select aria-label="Update progress" className="rounded-md border bg-background px-2 py-1 text-xs" value={i.fulfilment} onChange={async (e) => { const { error } = await supabase.rpc("update_fulfilment", { _order_item_id: i.id, _status: e.target.value }); if (error) toast.error(error.message); else { toast.success("Shopper can now see the update"); sales.refetch(); } }}><option value="paid">Paid</option><option value="making">Being made</option><option value="shipped">Shipped</option><option value="delivered">Delivered</option></select></td></tr>
                  ))}
                  {!s.length && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No sales yet.</td></tr>}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </div>
      <ReturnsDesk title="Returns on your pieces" />
      <GrowthStudio />
      {user && <CourseProposals userId={user.id} brand={profile.data?.studio_name || ""} />}
    </main>
  );
}
