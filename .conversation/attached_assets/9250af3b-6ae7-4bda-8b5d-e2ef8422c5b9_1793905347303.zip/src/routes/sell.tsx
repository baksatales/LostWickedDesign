import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { settingsQuery } from "@/lib/queries";

export const Route = createFileRoute("/sell")({
  head: () => ({
    meta: [
      { title: "Sell with Baksa Tales — open your maker studio" },
      { name: "description", content: "We bring your story to people who value handmade work, and help you grow with simple tools for pricing, orders and payouts." },
      { property: "og:title", content: "Sell with Baksa Tales" },
      { property: "og:description", content: "Your own maker page and story, orders and payouts in one dashboard, and a place in the Makers’ Academy." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Sell,
});

const GET = ["Your own maker page and story", "Orders, payouts and stock in one simple dashboard", "Pricing and profit calculators", "Corporate gifting briefs that fit your work", "A place in the Makers’ Academy"];
const NEXT = ["We look at your work to check it’s made by you, as described.", "We call you for a short chat.", "We set up your shop together. Your first products are checked by our team."];

function Sell() {
  const { data: fees } = useQuery(settingsQuery);
  return (
    <main className="mx-auto max-w-6xl px-5 py-16">
      <div className="grid gap-12 md:grid-cols-[1.2fr_1fr]">
        <div>
          <p className="font-deva text-2xl text-gold" lang="hi">दिल से दुनिया तक</p>
          <h1 className="mt-3 text-5xl md:text-7xl">Sell with Baksa Tales</h1>
          <p className="mt-6 max-w-lg text-xl text-muted-foreground">We bring your story to people who value handmade work, and help you grow with simple tools for pricing, orders and payouts. There’s no listing fee.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="cta" size="xl"><Link to="/auth" search={{ as: "maker" }}>Tell us about your work</Link></Button>
            <Button asChild variant="outline" size="xl"><Link to="/studio">See the maker dashboard</Link></Button>
          </div>
          <h2 className="mt-14 text-3xl">Here’s what happens next</h2>
          <ol className="mt-5 space-y-4">{NEXT.map((n, i) => <li key={n} className="flex gap-4"><span className="font-serif text-3xl text-gold">{i + 1}</span><span className="pt-2">{n}</span></li>)}</ol>
        </div>
        <aside className="h-fit rounded-lg bg-band p-8 text-teal-foreground shadow-soft">
          <h2 className="text-3xl">What you get</h2>
          <ul className="mt-6 space-y-4">{GET.map((g) => <li key={g} className="flex gap-3"><Check className="mt-0.5 h-5 w-5 shrink-0 text-gold-light" />{g}</li>)}</ul>
          {fees && <p className="mt-8 border-t border-teal-foreground/20 pt-5 text-sm opacity-85">Baksa’s commission is {fees.commissionPct}% of the price, taken only when you sell.</p>}
        </aside>
      </div>
    </main>
  );
}
