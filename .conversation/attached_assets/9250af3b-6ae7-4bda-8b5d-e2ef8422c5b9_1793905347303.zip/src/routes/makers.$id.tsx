import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BadgeCheck, Check } from "lucide-react";
import { approvedProductsQuery, makerQuery } from "@/lib/queries";
import { MakerAvatar } from "@/components/maker-card";
import { ProductCard } from "@/components/product-card";
import { MakerBadges } from "@/components/badge-pill";

export const Route = createFileRoute("/makers/$id")({
  head: () => ({
    meta: [
      { title: "Maker studio — Baksa Tales" },
      { name: "description", content: "Meet an independent Baksa Tales maker and shop their handmade pieces." },
      { property: "og:title", content: "Maker studio — Baksa Tales" },
      { property: "og:description", content: "Meet an independent Baksa Tales maker and shop their handmade pieces." },
    ],
  }),
  component: MakerPage,
});

function MakerPage() {
  const { id } = Route.useParams();
  const { data: m, isLoading } = useQuery(makerQuery(id));
  const { data: products } = useQuery(approvedProductsQuery);
  if (isLoading) return <main className="mx-auto max-w-6xl px-5 py-24 text-muted-foreground">Loading…</main>;
  if (!m) return <main className="mx-auto max-w-6xl px-5 py-24">We couldn’t find this maker. <Link to="/makers" className="text-primary underline">See all makers</Link></main>;
  const mine = (products ?? []).filter((p) => p.maker_id === m.id);
  return (
    <main>
      <section className="bg-hero">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-14 md:grid-cols-[1fr_1.2fr]">
          <div className="aspect-square overflow-hidden rounded-3xl shadow-soft"><MakerAvatar m={m} /></div>
          <div className="animate-rise">
            <div className="flex flex-wrap items-center gap-3"><p className="eyebrow">{m.craft || "Handmade in India"}</p><MakerBadges makerId={m.id} /></div>
            <h1 className="mt-3 flex items-center gap-3 text-5xl md:text-6xl">{m.brand}{m.is_founding && <BadgeCheck className="h-8 w-8 text-primary" aria-label="Founding maker" />}</h1>
            {m.tagline && <p className="mt-4 font-serif text-2xl italic text-primary">“{m.tagline}”</p>}
            {m.bio && <p className="mt-5 text-lg">{m.bio}</p>}
            {m.techniques.length > 0 && (
              <ul className="mt-6 space-y-2">{m.techniques.map((t) => <li key={t} className="flex gap-2"><Check className="mt-0.5 h-5 w-5 text-primary" />{t}</li>)}</ul>
            )}
          </div>
        </div>
      </section>
      {m.story && <section className="mx-auto max-w-3xl whitespace-pre-line px-5 py-14 text-lg leading-relaxed">{m.story}</section>}
      <section className="mx-auto max-w-6xl px-5 pb-10">
        <h2 className="text-3xl">From {m.brand}</h2>
        {mine.length ? (
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{mine.map((p) => <ProductCard key={p.id} p={p} />)}</div>
        ) : <p className="mt-4 text-muted-foreground">New pieces are on their way.</p>}
      </section>
    </main>
  );
}
