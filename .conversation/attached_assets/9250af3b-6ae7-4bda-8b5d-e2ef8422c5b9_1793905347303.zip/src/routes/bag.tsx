import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, X } from "lucide-react";
import { useCart } from "@/hooks/use-cart";
import { formatINR } from "@/lib/pricing";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/bag")({
  head: () => ({
    meta: [
      { title: "Your bag — Baksa Tales" },
      { name: "description", content: "Review the handmade gifts in your bag before checkout." },
      { property: "og:title", content: "Your bag — Baksa Tales" },
      { property: "og:description", content: "Review the handmade gifts in your bag before checkout." },
    ],
  }),
  component: Bag,
});

function Bag() {
  const { lines, setQty, remove } = useCart();
  const total = lines.reduce((a, l) => a + l.price * l.quantity, 0);
  return (
    <main className="mx-auto max-w-3xl px-5 py-14">
      <h1 className="text-5xl">Your bag</h1>
      {lines.length === 0 ? (
        <div className="mt-10 rounded-lg border border-dashed p-12 text-center text-muted-foreground">
          Your bag is empty. <Link to="/finder" className="text-primary underline">Find a gift</Link>
        </div>
      ) : (
        <>
          <ul className="mt-8 divide-y rounded-lg border bg-card">
            {lines.map((l) => (
              <li key={l.productId} className="flex items-center gap-4 p-4">
                <img src={l.imageUrl} alt="" className="h-20 w-20 rounded object-cover" />
                <div className="flex-1"><p className="text-xl">{l.name}</p><p className="eyebrow">{l.maker}</p></div>
                <div className="flex items-center gap-1">
                  <Button size="icon" variant="ghost" aria-label="Fewer" onClick={() => setQty(l.productId, l.quantity - 1)}><Minus className="h-4 w-4" /></Button>
                  <span className="w-6 text-center font-slab">{l.quantity}</span>
                  <Button size="icon" variant="ghost" aria-label="More" onClick={() => setQty(l.productId, l.quantity + 1)}><Plus className="h-4 w-4" /></Button>
                </div>
                <span className="w-24 text-right font-slab">{formatINR(l.price * l.quantity)}</span>
                <Button size="icon" variant="ghost" aria-label={`Remove ${l.name}`} onClick={() => remove(l.productId)}><X className="h-4 w-4" /></Button>
              </li>
            ))}
          </ul>
          <div className="mt-6 flex items-center justify-between">
            <p className="text-xl">Total <span className="ml-2 font-slab">{formatINR(total)}</span></p>
            <Button asChild size="lg" className="font-slab"><Link to="/checkout">Checkout</Link></Button>
          </div>
        </>
      )}
    </main>
  );
}
