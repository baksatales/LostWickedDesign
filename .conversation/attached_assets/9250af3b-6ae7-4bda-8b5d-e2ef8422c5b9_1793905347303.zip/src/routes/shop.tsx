import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { approvedProductsQuery } from "@/lib/queries";
import { ProductCard } from "@/components/product-card";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "All gifts — Baksa Tales" },
      { name: "description", content: "Every handmade gift currently available from Baksa Tales makers." },
      { property: "og:title", content: "All gifts — Baksa Tales" },
      { property: "og:description", content: "Every handmade gift currently available from Baksa Tales makers." },
    ],
  }),
  component: Shop,
});

function Shop() {
  const { data, isLoading } = useQuery(approvedProductsQuery);
  return (
    <main className="mx-auto max-w-6xl px-5 py-14">
      <p className="eyebrow">The collection</p>
      <h1 className="mt-2 text-5xl">All gifts</h1>
      {isLoading ? <p className="mt-10 text-muted-foreground">Loading…</p> : (
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {(data ?? []).map((p) => <ProductCard key={p.id} p={p} />)}
        </div>
      )}
    </main>
  );
}
