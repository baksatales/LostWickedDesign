import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { PageBody } from "@/components/site-pages";

export const Route = createFileRoute("/p/$slug")({
  loader: async ({ params }) => {
    const { data } = await supabase.from("site_pages").select("*").eq("slug", params.slug).eq("published", true).maybeSingle();
    if (!data) throw notFound();
    return data;
  },
  head: ({ loaderData }) => {
    const t = `${loaderData?.title ?? "Page"} — Baksa Tales`;
    const d = (loaderData?.body ?? "").slice(0, 150) || "Baksa Tales";
    return { meta: [{ title: t }, { name: "description", content: d }, { property: "og:title", content: t }, { property: "og:description", content: d }, { property: "og:type", content: "article" }, { name: "twitter:card", content: "summary" }] };
  },
  notFoundComponent: () => <main className="mx-auto max-w-3xl px-5 py-24"><h1 className="text-4xl">Page not found</h1><Link to="/" className="mt-4 inline-block text-primary">Back home</Link></main>,
  component: () => {
    const p = Route.useLoaderData();
    return (
      <main className="mx-auto max-w-3xl px-5 py-16">
        <p className="eyebrow">{p.kind === "blog" ? "Journal" : "Baksa Tales"}</p>
        <h1 className="mt-2 text-5xl">{p.title}</h1>
        {p.kind === "blog" && <p className="mt-2 text-sm text-muted-foreground">{new Date(p.created_at).toLocaleDateString("en-IN")}</p>}
        <PageBody body={p.body} />
      </main>
    );
  },
});
