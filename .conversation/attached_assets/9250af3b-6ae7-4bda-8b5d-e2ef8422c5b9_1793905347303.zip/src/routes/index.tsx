import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowRight, Ticket, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MakerCard } from "@/components/maker-card";
import { BaksaTrunk } from "@/components/baksa-trunk";
import { TodaysStories } from "@/components/story-viewer";
import { LeadForm } from "@/components/lead-form";
import { CourseCard, BookingDialog } from "@/components/academy";
import { approvedProductsQuery, coursesQuery, makersQuery, siteContentQuery, type Course } from "@/lib/queries";
import { productImage, RECIP } from "@/lib/catalog";
import { formatINR } from "@/lib/pricing";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Baksa Tales — every creation has a story | Handmade gifts from Indian makers" },
      { name: "description", content: "Open the baksa: real makers from across India, the stories behind their work, and handmade gifts picked in four questions." },
      { property: "og:title", content: "Baksa Tales — every creation has a story" },
      { property: "og:description", content: "Real makers, real stories, handmade gifts picked for the person in four questions." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const { data: products = [] } = useQuery(approvedProductsQuery);
  const { data: makers = [] } = useQuery(makersQuery);
  const { data: content } = useQuery(siteContentQuery);
  const { data: courses = [] } = useQuery(coursesQuery);
  const [booking, setBooking] = useState<Course | null>(null);
  const hero = content?.hero ?? {};
  const table = content?.table ?? {};
  const circle = content?.circle ?? {};
  const corp = content?.corporate ?? {};
  const founding = makers.filter((m) => m.is_founding);
  const featuredMaker = founding[0] ?? makers[0];
  const featuredProduct = products.find((p) => p.maker_id !== featuredMaker?.id) ?? products[0];
  const edit = products.slice(0, 5);

  return (
    <main>
      {/* 1. OPENING BAKSA — curiosity gap + three concrete next steps */}
      <section className="relative overflow-hidden bg-hero">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-12 md:grid-cols-[1fr_1.1fr] md:py-20">
          <div className="animate-rise">
            <p className="font-deva text-2xl text-gold" lang="hi">दिल से दुनिया तक</p>
            <h1 className="mt-3 text-5xl leading-[1.02] md:text-7xl">{hero.headline ?? "Every creation has a story."} <em className="text-primary">{hero.subline ?? "Find the one that speaks to yours."}</em></h1>
            <p className="mt-6 max-w-md text-xl text-muted-foreground">{hero.lede ?? "Open the baksa: real makers from across India, the stories behind their work, and the pieces you’ll want to give."}</p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild variant="cta" size="xl"><Link to="/finder">Find a gift <ArrowRight className="animate-nudge" /></Link></Button>
              <Button asChild variant="outline" size="xl"><Link to="/shop">Browse the Edit</Link></Button>
            </div>
          </div>
          <BaksaTrunk maker={featuredMaker} product={featuredProduct} />
        </div>
      </section>

      {/* 2. TODAY'S STORIES */}
      {makers.length > 0 && (
        <section className="border-b">
          <div className="mx-auto max-w-6xl px-5 py-10">
            <div className="mb-5"><h2 className="text-3xl">Today’s stories</h2><p className="text-muted-foreground">Tap a maker to step into their workshop.</p></div>
            <TodaysStories makers={makers} products={products} />
          </div>
        </section>
      )}

      {/* 3. RECIPIENT QUICK-START — foot-in-the-door */}
      <section className="bg-band text-teal-foreground">
        <div className="mx-auto grid max-w-6xl items-center gap-6 px-5 py-10 md:grid-cols-[1fr_1.6fr]">
          <div><p className="text-sm text-gold-light">Gift finder: 4 quick questions</p><h2 className="mt-1 text-4xl">Who are you shopping for?</h2></div>
          <div className="flex flex-wrap gap-3">
            {Object.entries(RECIP).map(([k, v]) => (
              <Link key={k} to="/finder" search={{ rec: k }} className="inline-flex min-h-12 items-center rounded-full bg-card px-5 text-sm font-semibold text-foreground transition-all hover:-translate-y-0.5 hover:bg-primary hover:text-primary-foreground">{v}</Link>
            ))}
          </div>
        </div>
      </section>

      {/* 4. THE BT EDIT — editorial bento */}
      {edit.length >= 3 && (
        <section className="mx-auto max-w-6xl px-5 py-20">
          <div className="mb-10 flex items-end justify-between gap-4">
            <div><h2 className="text-4xl md:text-6xl">The BT Edit</h2><p className="mt-2 max-w-lg text-muted-foreground">Chosen by our editors this season. Every piece comes with its maker’s story.</p></div>
            <Link to="/shop" className="text-sm font-semibold text-primary hover:underline">See the whole Edit →</Link>
          </div>
          <div className="grid gap-4 md:grid-cols-4 md:grid-rows-2">
            {edit.map((p, i) => (
              <Link key={p.id} to="/product/$id" params={{ id: p.id }} className={`group relative overflow-hidden rounded-3xl ${i === 0 ? "md:col-span-2 md:row-span-2" : ""}`}>
                <img src={productImage(p)} alt={p.name} loading="lazy" className={`h-full w-full object-cover transition-transform duration-700 group-hover:scale-105 ${i === 0 ? "aspect-square" : "aspect-[4/3]"}`} />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-foreground/80 to-transparent p-4 text-background">
                  <p className="text-xs opacity-80">{p.maker_name}</p>
                  <p className={`font-serif ${i === 0 ? "text-3xl" : "text-lg"}`}>{p.name}</p>
                  <p className="text-sm font-bold">{formatINR(p.price_inr)}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* 6. FOUNDING MAKERS */}
      {founding.length > 0 && (
        <section className="bg-secondary/60 py-20">
          <div className="mx-auto max-w-6xl px-5">
            <div className="mb-10 flex items-end justify-between gap-4">
              <div><p className="eyebrow">Founding makers</p><h2 className="mt-2 text-4xl md:text-5xl">Makers</h2></div>
              <Link to="/makers" className="text-sm font-semibold text-primary hover:underline">All makers →</Link>
            </div>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{founding.map((m) => <MakerCard key={m.id} m={m} />)}</div>
          </div>
        </section>
      )}

      {/* 7. THE MAKERS' TABLE — ticket stub */}
      <section className="bg-band py-20 text-teal-foreground">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="text-4xl">The Makers’ Table</h2>
          <p className="mt-2 opacity-80">Where the stories come off the screen.</p>
          <div className="ticket-edge mt-8 grid overflow-hidden rounded-2xl bg-secondary text-foreground md:grid-cols-[1.6fr_1fr]">
            <div className="p-8 md:p-10">
              <p className="eyebrow">{table.kicker ?? "Curated craft carnival, Delhi NCR"}</p>
              <h3 className="mt-2 text-4xl">{table.title ?? "Kala Samāgam"}</h3>
              <p className="mt-3 max-w-lg">{table.body ?? "Meet the makers, hold the work, hear the stories in person. Plus DSDT, Dil Se Duniya Tak: live conversations with founders."}</p>
              <p className="mt-4 inline-flex items-center gap-2 rounded-full bg-card px-4 py-1.5 text-sm font-semibold"><Ticket className="h-4 w-4 text-primary" />{table.date ?? "Next edition: [Dates to be announced]"}</p>
            </div>
            <div className="border-t-2 border-dashed border-border p-8 md:border-l-2 md:border-t-0">
              <p className="mb-4 font-semibold">Be first to hear the dates</p>
              <LeadForm kind="table" cta={table.cta ?? "Tell me when tickets open"} />
            </div>
          </div>
        </div>
      </section>

      {/* 8. ACADEMY */}
      {courses.length > 0 && (
        <section className="mx-auto max-w-6xl px-5 py-20">
          <div className="mb-10 flex items-end justify-between gap-4">
            <div><p className="eyebrow">Learn &amp; gather</p><h2 className="mt-2 text-4xl md:text-5xl">The Makers’ Academy</h2><p className="mt-2 text-muted-foreground">Learn a craft from the people who practise it, or learn the business of selling one.</p></div>
            <Link to="/academy" className="text-sm font-semibold text-primary hover:underline">All classes →</Link>
          </div>
          <div className="grid gap-6 md:grid-cols-2">{courses.slice(0, 2).map((c) => <CourseCard key={c.id} c={c} onBook={setBooking} />)}</div>
        </section>
      )}

      {/* 9. CORPORATE */}
      <section className="mx-auto max-w-6xl px-5">
        <div className="grid items-center gap-8 rounded-3xl border bg-card p-8 md:grid-cols-[auto_1fr_auto] md:p-12">
          <Building2 className="h-12 w-12 text-primary" />
          <div><p className="eyebrow">Corporate gifting</p><h2 className="mt-2 text-3xl">{corp.title ?? "Corporate gifting with a story inside"}</h2><p className="mt-2 text-muted-foreground">{corp.body ?? "For employees, clients, guests and weddings. Every box carries a card telling its maker’s story, so your gift is remembered for the right reasons."}</p></div>
          <Button asChild variant="cta" size="lg"><Link to="/corporate">Plan a corporate order</Link></Button>
        </div>
      </section>

      {/* 10. MAKER CTA */}
      <section className="mx-auto max-w-6xl px-5 pt-10">
        <div className="flex flex-col items-start justify-between gap-4 rounded-3xl bg-secondary p-8 md:flex-row md:items-center md:p-12">
          <div><h2 className="text-3xl">Sell with Baksa Tales</h2><p className="mt-2 max-w-xl text-muted-foreground">We bring your story to people who value handmade work, and help you grow with simple tools for pricing, orders and payouts. There’s no listing fee.</p></div>
          <Button asChild size="lg"><Link to="/sell">Tell us about your work</Link></Button>
        </div>
      </section>

      {/* 11. CIRCLE */}
      <section className="mx-auto max-w-6xl px-5 pt-20">
        <div className="grid items-center gap-8 md:grid-cols-2">
          <div><h2 className="text-4xl">{circle.title ?? "Join the Baksa circle"}</h2><p className="mt-3 text-lg text-muted-foreground">{circle.body ?? "New maker stories, early access to Kala Samāgam and first look at limited drops, on WhatsApp. One message a week at most."}</p></div>
          <LeadForm kind="circle" cta="Join on WhatsApp" />
        </div>
      </section>
      <BookingDialog course={booking} onClose={() => setBooking(null)} />
    </main>
  );
}
