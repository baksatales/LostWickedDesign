import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { coursesQuery, type Course } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { CourseCard, BookingDialog } from "@/components/academy";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/academy")({
  head: () => ({
    meta: [
      { title: "Makers’ Academy — learn a craft from the people who practise it | Baksa Tales" },
      { name: "description", content: "Recorded classes and live workshops from Indian makers and the Baksa Tales team: craft, pricing, photography and selling." },
      { property: "og:title", content: "Makers’ Academy — Baksa Tales" },
      { property: "og:description", content: "Recorded classes and live workshops from Indian makers and the Baksa Tales team." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Academy,
});

const TABS = [{ k: "all", l: "All classes" }, { k: "recorded", l: "Recorded classes" }, { k: "live", l: "Live workshops" }] as const;

function Academy() {
  const { data } = useQuery(coursesQuery);
  const [tab, setTab] = useState<(typeof TABS)[number]["k"]>("all");
  const [booking, setBooking] = useState<Course | null>(null);
  const list = (data ?? []).filter((c) => tab === "all" || c.format === tab);
  return (
    <main>
      <section className="bg-hero">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <p className="eyebrow">Learn &amp; gather</p>
          <h1 className="mt-3 max-w-3xl text-5xl md:text-6xl">The Makers’ Academy</h1>
          <p className="mt-4 max-w-xl text-lg text-muted-foreground">Learn a craft from the people who practise it, or learn the business of selling one.</p>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 py-12">
        <div role="tablist" className="flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button key={t.k} role="tab" aria-selected={tab === t.k} onClick={() => setTab(t.k)}
              className={cn("min-h-11 rounded-full border px-5 text-sm font-semibold", tab === t.k ? "border-foreground bg-foreground text-background" : "bg-card hover:border-foreground")}>{t.l}</button>
          ))}
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{list.map((c) => <CourseCard key={c.id} c={c} onBook={setBooking} />)}</div>
        {!list.length && <p className="mt-8 text-muted-foreground">No classes here yet.</p>}
        <div className="mt-16 grid items-center gap-6 rounded-3xl bg-band p-8 text-teal-foreground md:grid-cols-[1.5fr_1fr] md:p-12">
          <div><h2 className="text-3xl md:text-4xl">Want to teach?</h2><p className="mt-3 opacity-85">Makers on Baksa can propose a recorded class or a live workshop from their studio. We review it, help you get it ready, and list it here.</p></div>
          <Button asChild variant="cta" size="lg"><Link to="/studio">Propose a class</Link></Button>
        </div>
      </section>
      <BookingDialog course={booking} onClose={() => setBooking(null)} />
    </main>
  );
}
