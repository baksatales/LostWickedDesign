import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { splitOrder } from "./pricing";
import { chargeTestCard } from "./test-payment";

const Input = z.object({
  items: z.array(z.object({ productId: z.string().uuid(), quantity: z.number().int().min(1).max(20) })).min(1).max(30),
  card: z.object({ number: z.string().max(25), expiry: z.string().max(7), cvc: z.string().max(4), name: z.string().max(80) }),
  recipientName: z.string().trim().min(2).max(80),
  address: z.string().trim().min(8).max(400),
  giftNote: z.string().trim().max(300).optional(),
  quiz: z.record(z.string(), z.string()).optional(),
});

export const placeOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: z.infer<typeof Input>) => Input.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const ids = [...new Set(data.items.map((i) => i.productId))];

    // Prices and stock come from the database, never from the browser.
    const { data: products, error } = await supabase
      .from("products").select("id, name, price_inr, stock, maker_id, status").in("id", ids).eq("status", "approved");
    if (error) throw new Error("Could not load products");
    const byId = new Map((products ?? []).map((p) => [p.id, p]));
    const lines = data.items.map((i) => {
      const p = byId.get(i.productId);
      if (!p) throw new Error("A product in your bag is no longer available.");
      if (p.stock < i.quantity) throw new Error(`Only ${p.stock} left of ${p.name}.`);
      return { p, quantity: i.quantity };
    });

    const { data: settings } = await supabase.from("platform_settings").select("commission_pct, gateway_fee_pct").eq("id", 1).single();
    const fees = { commissionPct: Number(settings?.commission_pct ?? 12), gatewayFeePct: Number(settings?.gateway_fee_pct ?? 2) };
    const split = splitOrder(lines.map((l) => ({ unitPrice: l.p.price_inr, quantity: l.quantity })), fees);

    const payment = chargeTestCard(data.card, split.subtotal);
    if (!payment.ok) return { ok: false as const, error: payment.error };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: orderId, error: recErr } = await supabaseAdmin.rpc("record_order", {
      p_order: {
        shopper_id: userId, subtotal: split.subtotal, commission: split.commission, gateway_fee: split.gatewayFee,
        seller_earnings: split.sellerEarnings, commission_pct: fees.commissionPct, gateway_fee_pct: fees.gatewayFeePct,
        payment_ref: payment.reference, card_last4: payment.last4, recipient_name: data.recipientName,
        ship_address: data.address, gift_note: data.giftNote ?? null, quiz_answers: data.quiz ?? null,
      },
      p_items: lines.map((l, i) => { const sl = split.lines[i]!; return {
        product_id: l.p.id, maker_id: l.p.maker_id, product_name: l.p.name, unit_price: l.p.price_inr, quantity: l.quantity,
        line_total: sl.lineTotal, commission: sl.commission,
        gateway_fee: sl.gatewayFee, seller_earnings: sl.sellerEarnings,
      }; }),
    });
    if (recErr) {
      const m = /OUT_OF_STOCK:(.*)/.exec(recErr.message);
      return { ok: false as const, error: m ? `${m[1]} just sold out.` : "We couldn’t record the order. You were not charged." };
    }
    return { ok: true as const, orderId: orderId as string, total: split.subtotal, paymentRef: payment.reference };
  });
