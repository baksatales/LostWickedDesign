import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { splitCourse } from "./pricing";
import { chargeTestCard } from "./test-payment";

const Input = z.object({
  courseId: z.string().uuid(),
  card: z.object({ number: z.string().max(25), expiry: z.string().max(7), cvc: z.string().max(4), name: z.string().max(80) }),
});

export const bookCourse = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: z.infer<typeof Input>) => Input.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: course } = await supabase.from("courses").select("id, title, price_inr, seats, booked, status").eq("id", data.courseId).eq("status", "approved").maybeSingle();
    if (!course) return { ok: false as const, error: "This class is no longer available." };
    if (course.seats > 0 && course.booked >= course.seats) return { ok: false as const, error: "All seats are taken." };
    const { data: existing } = await supabase.from("course_enrolments").select("id").eq("course_id", course.id).eq("shopper_id", userId).maybeSingle();
    if (existing) return { ok: false as const, error: "You’re already booked on this class." };

    const { data: s } = await supabase.from("platform_settings").select("academy_share_pct").eq("id", 1).single();
    const split = splitCourse(course.price_inr, Number(s?.academy_share_pct ?? 30));
    const payment = chargeTestCard(data.card, split.price);
    if (!payment.ok) return { ok: false as const, error: payment.error };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.rpc("record_enrolment", {
      p: { course_id: course.id, shopper_id: userId, price: split.price, baksa_share: split.baksaShare, creator_share: split.creatorShare, payment_ref: payment.reference, card_last4: payment.last4 },
    });
    if (error) return { ok: false as const, error: /SOLD_OUT/.test(error.message) ? "The last seat just went." : "We couldn’t book your seat. You were not charged." };
    return { ok: true as const, title: course.title, paymentRef: payment.reference };
  });
