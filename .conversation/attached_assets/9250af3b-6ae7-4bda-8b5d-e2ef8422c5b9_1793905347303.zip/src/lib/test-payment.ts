// Test payment gateway. No real money moves. Card rules mirror common test cards:
// 4242 4242 4242 4242 succeeds, 4000 0000 0000 0002 is declined.

export type TestCard = { number: string; expiry: string; cvc: string; name: string };
export type PaymentResult =
  | { ok: true; reference: string; last4: string }
  | { ok: false; error: string };

export const TEST_CARD_SUCCESS = "4242424242424242";
export const TEST_CARD_DECLINE = "4000000000000002";

export function luhnValid(digits: string) {
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let d = Number(digits[digits.length - 1 - i]);
    if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return digits.length >= 12 && sum % 10 === 0;
}

export function chargeTestCard(card: TestCard, amount: number, now = new Date()): PaymentResult {
  const number = card.number.replace(/\s+/g, "");
  if (!/^\d{12,19}$/.test(number) || !luhnValid(number)) return { ok: false, error: "That card number isn’t valid." };
  const m = /^(\d{2})\s*\/\s*(\d{2})$/.exec(card.expiry.trim());
  if (!m) return { ok: false, error: "Use MM/YY for the expiry date." };
  const month = Number(m[1]), year = 2000 + Number(m[2]);
  if (month < 1 || month > 12) return { ok: false, error: "Use MM/YY for the expiry date." };
  if (new Date(year, month, 1) <= now) return { ok: false, error: "This card has expired." };
  if (!/^\d{3,4}$/.test(card.cvc)) return { ok: false, error: "The security code should be 3 or 4 digits." };
  if (card.name.trim().length < 2) return { ok: false, error: "Add the name on the card." };
  if (!(amount > 0)) return { ok: false, error: "Nothing to charge." };
  if (number === TEST_CARD_DECLINE) return { ok: false, error: "The card was declined. Try 4242 4242 4242 4242." };
  const reference = "test_pay_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  return { ok: true, reference, last4: number.slice(-4) };
}
