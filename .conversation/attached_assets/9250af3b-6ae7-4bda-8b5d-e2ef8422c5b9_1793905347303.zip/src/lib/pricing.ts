// Money split for marketplace orders. Pure and server-authoritative: the
// checkout server function uses these numbers when recording an order.

export type FeeSettings = { commissionPct: number; gatewayFeePct: number };

export type LineInput = { unitPrice: number; quantity: number };

export type LineSplit = {
  lineTotal: number;
  commission: number;
  gatewayFee: number;
  sellerEarnings: number;
};

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export function splitLine(line: LineInput, s: FeeSettings): LineSplit {
  if (!Number.isInteger(line.quantity) || line.quantity < 1) throw new Error("Quantity must be at least 1");
  if (!(line.unitPrice > 0)) throw new Error("Price must be positive");
  const lineTotal = round2(line.unitPrice * line.quantity);
  const commission = round2((lineTotal * s.commissionPct) / 100);
  const gatewayFee = round2((lineTotal * s.gatewayFeePct) / 100);
  const sellerEarnings = round2(lineTotal - commission - gatewayFee);
  return { lineTotal, commission, gatewayFee, sellerEarnings };
}

export function splitOrder(lines: LineInput[], s: FeeSettings) {
  const splits = lines.map((l) => splitLine(l, s));
  const sum = (k: keyof LineSplit) => round2(splits.reduce((a, x) => a + x[k], 0));
  return {
    lines: splits,
    subtotal: sum("lineTotal"),
    commission: sum("commission"),
    gatewayFee: sum("gatewayFee"),
    sellerEarnings: sum("sellerEarnings"),
  };
}

export const formatINR = (n: number) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: n % 1 ? 2 : 0 }).format(n);

// Academy: Baksa keeps academySharePct of the class price, the creator keeps the rest.
export function splitCourse(price: number, academySharePct: number) {
  if (!(price > 0)) throw new Error("Price must be positive");
  if (academySharePct < 0 || academySharePct > 100) throw new Error("Share must be 0-100");
  const baksaShare = round2((price * academySharePct) / 100);
  return { price: round2(price), baksaShare, creatorShare: round2(price - baksaShare) };
}

// Growth Studio: what one piece really earns a maker.
export function pieceProfit(i: { price: number; materials: number; labour: number; packaging: number; shipping: number }, s: FeeSettings) {
  const fees = round2((i.price * (s.commissionPct + s.gatewayFeePct)) / 100);
  const costs = round2(i.materials + i.labour + i.packaging + i.shipping);
  const profit = round2(i.price - fees - costs);
  const margin = i.price > 0 ? round2((profit / i.price) * 100) : 0;
  const keepPct = 1 - (s.commissionPct + s.gatewayFeePct) / 100;
  // Price that leaves a 35% margin after fees and costs.
  const suggested = keepPct - 0.35 > 0 ? Math.ceil(costs / (keepPct - 0.35) / 10) * 10 : 0;
  return { fees, costs, profit, margin, suggested };
}

export function breakEven(monthlyFixed: number, profitPerPiece: number) {
  if (profitPerPiece <= 0) return Infinity;
  return Math.ceil(monthlyFixed / profitPerPiece);
}
