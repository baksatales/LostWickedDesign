import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Product } from "./catalog";

export const approvedProductsQuery = queryOptions({
  queryKey: ["products", "approved"],
  queryFn: async () => {
    const { data, error } = await supabase.from("products").select("*").eq("status", "approved").order("created_at", { ascending: true });
    if (error) throw error;
    return data as Product[];
  },
});

export const productQuery = (id: string) => queryOptions({
  queryKey: ["product", id],
  queryFn: async () => {
    const { data, error } = await supabase.from("products").select("*").eq("id", id).maybeSingle();
    if (error) throw error;
    return data as Product | null;
  },
});

export const settingsQuery = queryOptions({
  queryKey: ["settings"],
  queryFn: async () => {
    const { data, error } = await supabase.from("platform_settings").select("*").eq("id", 1).single();
    if (error) throw error;
    return { commissionPct: Number(data.commission_pct), gatewayFeePct: Number(data.gateway_fee_pct) };
  },
});

export type Maker = {
  id: string; brand: string; craft: string; tagline: string; bio: string; story: string;
  techniques: string[]; image_key: string | null; is_founding: boolean; published: boolean;
};

export const makersQuery = queryOptions({
  queryKey: ["makers"],
  queryFn: async () => {
    const { data, error } = await supabase.from("makers").select("*").eq("published", true)
      .order("is_founding", { ascending: false }).order("created_at", { ascending: true });
    if (error) throw error;
    return data as Maker[];
  },
});

export const makerQuery = (id: string) => queryOptions({
  queryKey: ["maker", id],
  queryFn: async () => {
    const { data, error } = await supabase.from("makers").select("*").eq("id", id).maybeSingle();
    if (error) throw error;
    return data as Maker | null;
  },
});

export type Badge = { id: string; slug: string; label: string; description: string; tone: string; active: boolean };
export const badgesQuery = queryOptions({
  queryKey: ["badges"],
  queryFn: async () => {
    const { data, error } = await supabase.from("badges").select("*").order("created_at");
    if (error) throw error;
    return data as Badge[];
  },
});
export const makerBadgesQuery = queryOptions({
  queryKey: ["maker-badges"],
  queryFn: async () => {
    const { data, error } = await supabase.from("maker_badges").select("maker_id, badge_id");
    if (error) throw error;
    return data;
  },
});

export type Course = {
  id: string; maker_id: string | null; creator_name: string; title: string; description: string;
  format: "recorded" | "live"; schedule: string; meeting_link: string | null; price_inr: number;
  seats: number; booked: number; status: string; review_note: string | null; created_at: string;
};
export const coursesQuery = queryOptions({
  queryKey: ["courses", "approved"],
  queryFn: async () => {
    const { data, error } = await supabase.from("courses").select("*").eq("status", "approved").order("created_at");
    if (error) throw error;
    return data as Course[];
  },
});

export type ContentBlock = { eyebrow?: string; headline?: string; subline?: string; lede?: string; kicker?: string; title?: string; body?: string; date?: string; cta?: string };
export type SiteContent = { hero?: ContentBlock; table?: ContentBlock; circle?: ContentBlock; corporate?: ContentBlock };
export const siteContentQuery = queryOptions({
  queryKey: ["site-content"],
  queryFn: async () => {
    const { data, error } = await supabase.from("site_content").select("key, value");
    if (error) throw error;
    return Object.fromEntries((data ?? []).map((r) => [r.key, r.value as ContentBlock])) as SiteContent;
  },
});
