// Gifting vocabulary and the four-question finder, taken from the Baksa Tales prototype.
import lotuspond from "@/assets/catalog/t-lotuspond.webp.asset.json";
import crimson from "@/assets/catalog/t-crimson.webp.asset.json";
import message from "@/assets/catalog/t-message.webp.asset.json";
import teapot from "@/assets/catalog/t-teapot.webp.asset.json";
import marigold from "@/assets/catalog/t-marigold.webp.asset.json";
import sunflower from "@/assets/catalog/t-sunflower.webp.asset.json";
import shell from "@/assets/catalog/t-shell.webp.asset.json";
import bluelotus from "@/assets/catalog/t-bluelotus.webp.asset.json";
import pinkpeony from "@/assets/catalog/t-pinkpeony.webp.asset.json";
import succulents from "@/assets/catalog/t-succulents.webp.asset.json";
import gajra from "@/assets/catalog/t-gajra.webp.asset.json";
import starfish from "@/assets/catalog/t-starfish.webp.asset.json";
import svSandhya from "@/assets/catalog/sv-sandhya.webp.asset.json";
import anRange from "@/assets/catalog/an-range.webp.asset.json";

const IMAGES: Record<string, string> = {
  "t-lotuspond": lotuspond.url, "t-crimson": crimson.url, "t-message": message.url, "t-teapot": teapot.url,
  "t-marigold": marigold.url, "t-sunflower": sunflower.url, "t-shell": shell.url, "t-bluelotus": bluelotus.url,
  "t-pinkpeony": pinkpeony.url, "t-succulents": succulents.url, "t-gajra": gajra.url, "t-starfish": starfish.url,
  "sv-sandhya": svSandhya.url, "an-range": anRange.url,
};

export const RECIP = { parent: "A parent", partner: "A partner", friend: "A friend", colleague: "A colleague or client", self: "Myself" } as const;
export const OCC = { diwali: "Diwali or a festival", wedding: "A wedding", birthday: "A birthday", thanks: "Saying thank you", housewarming: "A new home", justbecause: "Just because" } as const;
export const FEEL = { heart: "Show how much they mean to me", showstopper: "Make it a moment they’ll remember", soother: "Help them slow down and relax", thoughtful: "Be something useful they’ll love", explorer: "Introduce them to something new" } as const;
export const FEEL_WHY: Record<keyof typeof FEEL, string> = {
  heart: "Personal and warm, a gift that says it for you",
  showstopper: "Made to be noticed the moment it’s unwrapped",
  soother: "Calm, quiet and made for slowing down",
  thoughtful: "Useful and lovely, something they’ll reach for",
  explorer: "A craft they may never have seen before",
};
export const BUDGET = {
  b1: { label: "Under ₹1,500", min: 0, max: 1500 },
  b2: { label: "₹1,500 to ₹3,500", min: 1500, max: 3500 },
  b3: { label: "₹3,500 to ₹8,000", min: 3500, max: 8000 },
  b4: { label: "₹8,000 and above", min: 8000, max: 1e9 },
} as const;

export type QuizAnswers = { rec?: keyof typeof RECIP; occ?: keyof typeof OCC; feel?: keyof typeof FEEL; budget?: keyof typeof BUDGET };

export const QUIZ_STEPS = [
  { key: "rec", q: "Who is the gift for?", opts: RECIP },
  { key: "occ", q: "What’s the occasion?", opts: OCC },
  { key: "feel", q: "What would you like the gift to do?", opts: FEEL },
  { key: "budget", q: "What would you like to spend?", opts: Object.fromEntries(Object.entries(BUDGET).map(([k, v]) => [k, v.label])) },
] as const;

export type Product = {
  id: string; maker_id: string; maker_name: string; name: string; description: string;
  price_inr: number; stock: number; image_key: string | null; image_url: string | null;
  recipients: string[]; occasions: string[]; feelings: string[]; status: string;
  review_note?: string | null; created_at?: string;
};

export const imageFor = (key?: string | null) => (key ? IMAGES[key] : undefined);

export const productImage = (p: Pick<Product, "image_key" | "image_url">) =>
  p.image_url || (p.image_key ? IMAGES[p.image_key] : undefined) || (IMAGES["t-lotuspond"] as string);

export type Recommendation = { product: Product; score: number; reasons: string[] };

export function recommend(products: Product[], a: QuizAnswers): Recommendation[] {
  const b = BUDGET[a.budget ?? "b4"];
  const out: Recommendation[] = [];
  for (const p of products) {
    if (p.status !== "approved" || p.stock <= 0) continue;
    if (p.price_inr > b.max * 1.1) continue;
    const occ = !!a.occ && p.occasions.includes(a.occ);
    const feel = !!a.feel && p.feelings.includes(a.feel);
    const rec = !!a.rec && p.recipients.includes(a.rec);
    if (!occ && !feel) continue; // never suggest on budget or recipient alone
    let score = 0; const reasons: string[] = [];
    if (occ) { score += 3; reasons.push(`Suits ${OCC[a.occ!].toLowerCase()}`); }
    if (feel) { score += 3; reasons.push(FEEL_WHY[a.feel!]); }
    if (rec) { score += 2; reasons.push(`A good fit for ${RECIP[a.rec!].toLowerCase().replace("myself", "yourself")}`); }
    if (p.price_inr >= b.min && p.price_inr < b.max) { score += 2; reasons.push("Within your budget"); }
    else if (p.price_inr < b.min) { score += 1; reasons.push("Under your budget"); }
    else reasons.push("A little over your budget");
    out.push({ product: p, score, reasons });
  }
  return out.sort((x, y) => y.score - x.score || x.product.price_inr - y.product.price_inr);
}
