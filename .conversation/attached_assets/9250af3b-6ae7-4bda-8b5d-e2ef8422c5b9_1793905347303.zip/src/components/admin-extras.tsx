import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { badgesQuery, makerBadgesQuery, siteContentQuery, type Badge, type Course } from "@/lib/queries";
import { formatINR } from "@/lib/pricing";
import { BadgePill, BADGE_TONES } from "@/components/badge-pill";
import { StatusPill, StatTile } from "@/components/dashboard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

/* ---------- Badges: create, edit, hide, assign ---------- */
export function BadgeManager() {
  const qc = useQueryClient();
  const { data: badges = [] } = useQuery(badgesQuery);
  const { data: links = [] } = useQuery(makerBadgesQuery);
  const makers = useQuery({ queryKey: ["admin-makers"], queryFn: async () => (await supabase.from("makers").select("id, brand").order("brand")).data ?? [] });
  const [edit, setEdit] = useState<Partial<Badge> | null>(null);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["badges"] }); qc.invalidateQueries({ queryKey: ["maker-badges"] }); };

  async function save() {
    if (!edit?.label?.trim()) return;
    const row = { label: edit.label.trim(), description: edit.description ?? "", tone: edit.tone ?? "sage", active: edit.active ?? true,
      slug: edit.slug || edit.label.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") };
    const { error } = edit.id ? await supabase.from("badges").update(row).eq("id", edit.id) : await supabase.from("badges").insert(row);
    if (error) toast.error(error.message); else { toast.success("Badge saved"); setEdit(null); refresh(); }
  }
  async function toggle(makerId: string, badgeId: string, on: boolean) {
    const { error } = on ? await supabase.from("maker_badges").delete().eq("maker_id", makerId).eq("badge_id", badgeId)
      : await supabase.from("maker_badges").insert({ maker_id: makerId, badge_id: badgeId });
    if (error) toast.error(error.message); else refresh();
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
      <div className="space-y-3">
        <div className="flex items-center justify-between"><h3 className="text-xl">Badges</h3><Button size="sm" onClick={() => setEdit({ tone: "sage", active: true })}>New badge</Button></div>
        {badges.map((b) => (
          <div key={b.id} className={cn("flex items-center justify-between gap-3 rounded-xl border bg-card p-3", !b.active && "opacity-50")}>
            <div><BadgePill b={b} /><p className="mt-1 text-xs text-muted-foreground">{b.description}</p></div>
            <Button size="sm" variant="ghost" onClick={() => setEdit(b)}>Edit</Button>
          </div>
        ))}
        {edit && (
          <div className="space-y-3 rounded-xl border bg-card p-4">
            <div className="space-y-1"><Label htmlFor="bl">Label</Label><Input id="bl" value={edit.label ?? ""} onChange={(e) => setEdit({ ...edit, label: e.target.value })} /></div>
            <div className="space-y-1"><Label htmlFor="bd">What it means (shown on hover)</Label><Input id="bd" value={edit.description ?? ""} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></div>
            <div className="flex flex-wrap gap-2">{Object.keys(BADGE_TONES).map((t) => (
              <button key={t} type="button" onClick={() => setEdit({ ...edit, tone: t })} className={cn("rounded-full px-3 py-1 text-xs font-semibold", BADGE_TONES[t], edit.tone === t && "ring-2 ring-foreground")}>{t}</button>
            ))}</div>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={edit.active ?? true} onChange={(e) => setEdit({ ...edit, active: e.target.checked })} /> Show on the site</label>
            <div className="flex gap-2"><Button size="sm" onClick={save}>Save</Button><Button size="sm" variant="ghost" onClick={() => setEdit(null)}>Cancel</Button></div>
          </div>
        )}
      </div>
      <div>
        <h3 className="text-xl">Assign to makers</h3>
        <div className="mt-3 overflow-x-auto rounded-xl border bg-card">
          <table className="w-full text-sm">
            <thead><tr className="text-left text-xs text-muted-foreground"><th className="p-3">Maker</th>{badges.map((b) => <th key={b.id} className="p-3">{b.label}</th>)}</tr></thead>
            <tbody>{(makers.data ?? []).map((m) => (
              <tr key={m.id} className="border-t"><td className="p-3 font-semibold">{m.brand}</td>
                {badges.map((b) => { const on = links.some((l) => l.maker_id === m.id && l.badge_id === b.id); return (
                  <td key={b.id} className="p-3"><input type="checkbox" aria-label={`${b.label} for ${m.brand}`} checked={on} onChange={() => toggle(m.id, b.id, on)} /></td>
                ); })}
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ---------- Academy: review proposals, links, revenue split ---------- */
export function AcademyAdmin() {
  const qc = useQueryClient();
  const courses = useQuery({ queryKey: ["admin-courses"], queryFn: async () => ((await supabase.from("courses").select("*").order("created_at", { ascending: false })).data ?? []) as Course[] });
  const enrol = useQuery({ queryKey: ["admin-enrolments"], queryFn: async () => (await supabase.from("course_enrolments").select("price_inr, baksa_share_inr, creator_share_inr")).data ?? [] });
  const share = useQuery({ queryKey: ["academy-share"], queryFn: async () => Number((await supabase.from("platform_settings").select("academy_share_pct").eq("id", 1).single()).data?.academy_share_pct ?? 30) });
  const [pct, setPct] = useState("");
  const e = enrol.data ?? [];
  const sum = (k: "price_inr" | "baksa_share_inr" | "creator_share_inr") => e.reduce((a, x) => a + Number(x[k]), 0);
  async function update(c: Course, patch: Partial<Course>, msg: string) {
    const { error } = await supabase.from("courses").update(patch).eq("id", c.id);
    if (error) toast.error(error.message); else { toast.success(msg); qc.invalidateQueries({ queryKey: ["admin-courses"] }); qc.invalidateQueries({ queryKey: ["courses"] }); }
  }
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-4">
        <StatTile label="Academy sales" value={formatINR(sum("price_inr"))} />
        <StatTile label="Seats sold" value={String(e.length)} />
        <StatTile label="Baksa share" value={formatINR(sum("baksa_share_inr"))} accent />
        <StatTile label="Creator share" value={formatINR(sum("creator_share_inr"))} />
      </div>
      <form className="flex flex-wrap items-end gap-3 rounded-xl border bg-card p-4" onSubmit={async (ev) => {
        ev.preventDefault();
        const { error } = await supabase.from("platform_settings").update({ academy_share_pct: Number(pct) }).eq("id", 1);
        if (error) toast.error(error.message); else { toast.success("Academy share updated for new bookings"); share.refetch(); setPct(""); }
      }}>
        <div className="space-y-1"><Label htmlFor="as">Baksa’s share of class sales (%)</Label><Input id="as" type="number" min={0} max={100} placeholder={String(share.data ?? 30)} value={pct} onChange={(ev) => setPct(ev.target.value)} className="w-40" /></div>
        <Button type="submit" disabled={!pct}>Save</Button>
      </form>
      <ul className="space-y-3">{(courses.data ?? []).map((c) => <CourseRow key={c.id} c={c} onUpdate={update} />)}</ul>
    </div>
  );
}

function CourseRow({ c, onUpdate }: { c: Course; onUpdate: (c: Course, p: Partial<Course>, m: string) => void }) {
  const [link, setLink] = useState(c.meeting_link ?? "");
  const [note, setNote] = useState("");
  return (
    <li className="rounded-xl border bg-card p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div><p className="font-semibold">{c.title}</p><p className="text-sm text-muted-foreground">{c.creator_name} · {c.format === "live" ? "Live" : "Recorded"} · {c.schedule} · {formatINR(c.price_inr)} · {c.format === "live" ? `${c.booked}/${c.seats} seats` : `${c.booked} sold`}</p></div>
        <StatusPill status={c.status} />
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Input placeholder="Joining or lesson link for buyers" value={link} onChange={(e) => setLink(e.target.value)} className="max-w-sm" />
        <Button size="sm" variant="outline" onClick={() => onUpdate(c, { meeting_link: link.trim() || null }, "Link saved")}>Save link</Button>
        {c.status !== "approved" && <Button size="sm" onClick={() => onUpdate(c, { status: "approved", review_note: null }, `${c.title} is listed`)}>Approve &amp; list</Button>}
        <Input placeholder="Note to the maker" value={note} onChange={(e) => setNote(e.target.value)} className="max-w-xs" />
        <Button size="sm" variant="ghost" onClick={() => onUpdate(c, { status: "rejected", review_note: note || "Please revise and resubmit" }, c.status === "approved" ? "Unlisted" : "Sent back")}>{c.status === "approved" ? "Unlist" : "Send back"}</Button>
      </div>
    </li>
  );
}

/* ---------- Home page text ---------- */
const CONTENT_FIELDS: Record<string, { label: string; fields: string[] }> = {
  hero: { label: "Opening section", fields: ["eyebrow", "headline", "subline", "lede"] },
  table: { label: "The Makers’ Table", fields: ["kicker", "title", "body", "date", "cta"] },
  corporate: { label: "Corporate gifting", fields: ["title", "body"] },
  circle: { label: "Baksa circle sign-up", fields: ["title", "body"] },
};
export function ContentEditor() {
  const qc = useQueryClient();
  const { data } = useQuery(siteContentQuery);
  const [draft, setDraft] = useState<Record<string, Record<string, string>>>({});
  if (!data) return null;
  return (
    <div className="grid gap-6 md:grid-cols-2">
      {Object.entries(CONTENT_FIELDS).map(([key, def]) => {
        const v: Record<string, string> = { ...((data as Record<string, Record<string, string>>)[key] ?? {}), ...(draft[key] ?? {}) };
        return (
          <form key={key} className="space-y-3 rounded-xl border bg-card p-5" onSubmit={async (e) => {
            e.preventDefault();
            const { error } = await supabase.from("site_content").upsert({ key, value: v, updated_at: new Date().toISOString() });
            if (error) toast.error(error.message); else { toast.success(`${def.label} updated`); qc.invalidateQueries({ queryKey: ["site-content"] }); }
          }}>
            <h3 className="text-xl">{def.label}</h3>
            {def.fields.map((f) => (
              <div key={f} className="space-y-1"><Label htmlFor={`${key}-${f}`} className="capitalize">{f}</Label>
                {f === "body" || f === "lede"
                  ? <Textarea id={`${key}-${f}`} value={v[f] ?? ""} onChange={(e) => setDraft({ ...draft, [key]: { ...draft[key], [f]: e.target.value } })} />
                  : <Input id={`${key}-${f}`} value={v[f] ?? ""} onChange={(e) => setDraft({ ...draft, [key]: { ...draft[key], [f]: e.target.value } })} />}
              </div>
            ))}
            <Button type="submit" size="sm">Save</Button>
          </form>
        );
      })}
    </div>
  );
}

/* ---------- Sign-ups and corporate briefs ---------- */
export function LeadsTable() {
  const { data = [] } = useQuery({ queryKey: ["admin-leads"], queryFn: async () => (await supabase.from("leads").select("*").order("created_at", { ascending: false })).data ?? [] });
  const label: Record<string, string> = { circle: "Baksa circle", table: "Makers’ Table waitlist", corporate: "Corporate brief" };
  return (
    <div className="overflow-x-auto rounded-xl border bg-card">
      <table className="w-full text-left text-sm">
        <thead className="text-xs text-muted-foreground"><tr><th className="p-3">Type</th><th className="p-3">Name</th><th className="p-3">Contact</th><th className="p-3">Details</th><th className="p-3">Date</th></tr></thead>
        <tbody>
          {data.map((l) => <tr key={l.id} className="border-t align-top"><td className="p-3">{label[l.kind]}</td><td className="p-3">{l.name}</td><td className="p-3">{l.contact}</td><td className="max-w-sm p-3">{l.details}</td><td className="p-3">{new Date(l.created_at).toLocaleDateString("en-IN")}</td></tr>)}
          {!data.length && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No sign-ups yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
