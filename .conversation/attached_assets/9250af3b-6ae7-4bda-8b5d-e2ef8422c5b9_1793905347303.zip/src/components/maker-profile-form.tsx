import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { makerQuery } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export function MakerProfileForm({ userId }: { userId: string }) {
  const qc = useQueryClient();
  const { data: m } = useQuery(makerQuery(userId));
  const [f, setF] = useState({ brand: "", craft: "", tagline: "", bio: "", story: "", techniques: "" });
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (m) setF({ brand: m.brand, craft: m.craft, tagline: m.tagline, bio: m.bio, story: m.story, techniques: m.techniques.join("\n") });
  }, [m]);
  if (!m) return null;
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    const { error } = await supabase.from("makers").update({
      brand: f.brand.trim(), craft: f.craft.trim(), tagline: f.tagline.trim(), bio: f.bio.trim(), story: f.story.trim(),
      techniques: f.techniques.split("\n").map((t) => t.trim()).filter(Boolean),
    }).eq("id", userId);
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Studio profile saved");
    qc.invalidateQueries({ queryKey: ["maker", userId] }); qc.invalidateQueries({ queryKey: ["makers"] });
  }

  return (
    <details className="mt-8 rounded-2xl border bg-card p-6 shadow-soft">
      <summary className="cursor-pointer text-lg font-semibold">Your public studio page <span className="text-sm font-normal text-muted-foreground">· shoppers see this</span></summary>
      <form onSubmit={save} className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5"><Label htmlFor="mb">Studio name</Label><Input id="mb" required value={f.brand} onChange={set("brand")} /></div>
        <div className="space-y-1.5"><Label htmlFor="mc">Your craft</Label><Input id="mc" placeholder="e.g. Hand-thrown terracotta" value={f.craft} onChange={set("craft")} /></div>
        <div className="space-y-1.5 md:col-span-2"><Label htmlFor="mt">One-line tagline</Label><Input id="mt" value={f.tagline} onChange={set("tagline")} /></div>
        <div className="space-y-1.5 md:col-span-2"><Label htmlFor="mbi">Short bio</Label><Textarea id="mbi" rows={2} value={f.bio} onChange={set("bio")} /></div>
        <div className="space-y-1.5"><Label htmlFor="ms">Your story</Label><Textarea id="ms" rows={5} value={f.story} onChange={set("story")} /></div>
        <div className="space-y-1.5"><Label htmlFor="mtech">Techniques (one per line)</Label><Textarea id="mtech" rows={5} value={f.techniques} onChange={set("techniques")} /></div>
        <div className="flex items-center gap-4 md:col-span-2">
          <Button type="submit" disabled={busy}>{busy ? "Saving…" : "Save profile"}</Button>
          <Link to="/makers/$id" params={{ id: userId }} className="text-sm font-semibold text-primary hover:underline">View my page →</Link>
        </div>
      </form>
    </details>
  );
}
