import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { productImage, type Product } from "@/lib/catalog";
import { formatINR } from "@/lib/pricing";
import type { Maker } from "@/lib/queries";
import { MakerAvatar } from "@/components/maker-card";
import { MakerBadges } from "@/components/badge-pill";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";

// Today's Stories: familiar Instagram-style rings lower effort; the 3rd slide
// ends on a single product with one action (narrative transportation → act).
export function TodaysStories({ makers, products }: { makers: Maker[]; products: Product[] }) {
  const [active, setActive] = useState<number | null>(null);
  return (
    <>
      <div className="flex gap-5 overflow-x-auto pb-2">
        {makers.map((m, i) => (
          <button key={m.id} onClick={() => setActive(i)} className="group flex w-24 shrink-0 flex-col items-center gap-2">
            <span className="story-ring rounded-full p-[3px] transition-transform group-hover:scale-105">
              <span className="block h-20 w-20 overflow-hidden rounded-full border-4 border-background"><MakerAvatar m={m} /></span>
            </span>
            <span className="line-clamp-1 text-xs font-semibold">{m.brand}</span>
          </button>
        ))}
      </div>
      {active !== null && makers[active] && (
        <StoryModal key={makers[active]!.id} maker={makers[active]!} product={products.find((p) => p.maker_id === makers[active]!.id)}
          onClose={() => setActive(null)} onNext={() => setActive(active + 1 < makers.length ? active + 1 : null)} />
      )}
    </>
  );
}

function StoryModal({ maker, product, onClose, onNext }: { maker: Maker; product?: Product | undefined; onClose: () => void; onNext: () => void }) {
  const total = product ? 3 : 2;
  const [slide, setSlide] = useState(0);
  const { add } = useCart();
  useEffect(() => {
    const t = setTimeout(() => (slide + 1 < total ? setSlide(slide + 1) : onNext()), 6000);
    return () => clearTimeout(t);
  }, [slide, total, onNext]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div role="dialog" aria-modal="true" aria-label={`${maker.brand} story`} className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/80 p-4" onClick={onClose}>
      <div className="relative flex h-[min(680px,90vh)] w-full max-w-sm flex-col overflow-hidden rounded-3xl bg-card" onClick={(e) => e.stopPropagation()}>
        <div className="absolute inset-x-3 top-3 z-10 flex gap-1">
          {Array.from({ length: total }).map((_, i) => (
            <div key={i} className="h-1 flex-1 overflow-hidden rounded bg-background/50">
              {i < slide && <div className="h-full bg-background" />}
              {i === slide && <div key={slide} className="story-progress h-full bg-background" />}
            </div>
          ))}
        </div>
        <button onClick={onClose} className="absolute right-3 top-6 z-10 rounded-full bg-background/80 p-1.5" aria-label="Close"><X className="h-4 w-4" /></button>
        <div className="relative flex-1">
          {slide === 0 && (
            <div className="flex h-full flex-col">
              <div className="h-3/5 overflow-hidden"><MakerAvatar m={maker} /></div>
              <div className="p-6"><p className="eyebrow">{maker.craft}</p><h3 className="mt-1 text-3xl">{maker.brand}</h3><MakerBadges makerId={maker.id} className="mt-3" />{maker.tagline && <p className="mt-3 font-serif italic">“{maker.tagline}”</p>}</div>
            </div>
          )}
          {slide === 1 && (
            <div className="flex h-full flex-col justify-center bg-band p-8 text-teal-foreground">
              <p className="eyebrow text-teal-foreground/70">Inside the workshop</p>
              <p className="mt-4 line-clamp-[10] font-serif text-xl leading-snug">{maker.bio || maker.story}</p>
              {maker.techniques.length > 0 && <ul className="mt-5 space-y-1 text-sm opacity-90">{maker.techniques.slice(0, 3).map((t) => <li key={t}>· {t}</li>)}</ul>}
            </div>
          )}
          {slide === 2 && product && (
            <div className="flex h-full flex-col">
              <div className="h-3/5 overflow-hidden"><img src={productImage(product)} alt={product.name} className="h-full w-full object-cover" /></div>
              <div className="p-6">
                <h3 className="text-2xl">{product.name}</h3>
                <p className="mt-1 font-bold">{formatINR(product.price_inr)} {product.stock <= 3 && <span className="ml-2 text-xs text-warning">Only {product.stock} left</span>}</p>
                <div className="mt-4 flex gap-2">
                  <Button variant="cta" className="flex-1" onClick={() => { add({ productId: product.id, name: product.name, price: product.price_inr, imageUrl: productImage(product), maker: product.maker_name }); toast.success("Added to your bag"); }}>Add to bag</Button>
                  <Button asChild variant="outline"><Link to="/product/$id" params={{ id: product.id }}>View</Link></Button>
                </div>
              </div>
            </div>
          )}
          <button className="absolute inset-y-0 left-0 w-1/4" aria-label="Previous" onClick={() => setSlide(Math.max(0, slide - 1))}><ChevronLeft className="sr-only" /></button>
          {slide < total - 1 && <button className="absolute right-0 top-12 bottom-40 w-1/4" aria-label="Next" onClick={() => setSlide(slide + 1)}><ChevronRight className="sr-only" /></button>}
        </div>
      </div>
    </div>
  );
}
