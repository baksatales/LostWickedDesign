import { useQuery } from "@tanstack/react-query";
import { badgesQuery, makerBadgesQuery, type Badge } from "@/lib/queries";
import { cn } from "@/lib/utils";

export const BADGE_TONES: Record<string, string> = {
  sage: "bg-sage text-sage-foreground",
  marigold: "bg-coral/15 text-warning",
  navy: "bg-teal-soft text-teal",
  ember: "bg-primary/10 text-primary",
  cream: "bg-secondary text-foreground",
};

export function BadgePill({ b, className }: { b: Pick<Badge, "label" | "tone" | "description">; className?: string }) {
  return (
    <span title={b.description} className={cn("inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold", BADGE_TONES[b.tone] ?? BADGE_TONES["cream"], className)}>
      {b.label}
    </span>
  );
}

export function useMakerBadges(makerId: string | undefined) {
  const { data: badges } = useQuery(badgesQuery);
  const { data: links } = useQuery(makerBadgesQuery);
  if (!makerId) return [];
  const ids = new Set((links ?? []).filter((l) => l.maker_id === makerId).map((l) => l.badge_id));
  return (badges ?? []).filter((b) => b.active && ids.has(b.id));
}

export function MakerBadges({ makerId, className }: { makerId: string; className?: string }) {
  const list = useMakerBadges(makerId);
  if (!list.length) return null;
  return <div className={cn("flex flex-wrap gap-2", className)}>{list.map((b) => <BadgePill key={b.id} b={b} />)}</div>;
}
