import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const RETURN_WINDOW_DAYS = 7;
export const RETURN_LABEL: Record<string, string> = { requested: "Return requested", approved: "Return approved", declined: "Return declined", refunded: "Refunded" };

// Shared returns desk. Makers see returns on their pieces; admins see every return.
// Which rows load is decided by the database rules, not by this component.
export function ReturnsDesk({ title = "Returns" }: { title?: string }) {
  const qc = useQueryClient();
  const { data = [] } = useQuery({
    queryKey: ["returns-desk"],
    queryFn: async () => {
      const { data, error } = await supabase.from("return_requests").select("*, order_items(product_name, quantity, line_total_inr)").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
  async function setStatus(id: string, status: string) {
    const note = status === "declined" ? window.prompt("Tell the buyer why (they will see this)") : null;
    if (status === "declined" && !note) return;
    const { error } = await supabase.from("return_requests").update({ status, maker_note: note, updated_at: new Date().toISOString() }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success(RETURN_LABEL[status]);
    qc.invalidateQueries({ queryKey: ["returns-desk"] });
  }
  return (
    <section className="mt-14">
      <h2 className="text-3xl">{title}</h2>
      <ul className="mt-4 space-y-3">
        {data.map((r) => (
          <li key={r.id} className="flex flex-wrap items-center gap-4 rounded-lg border bg-card p-4">
            <div className="min-w-0 flex-1">
              <p className="font-serif text-lg">{r.order_items?.product_name} × {r.order_items?.quantity}</p>
              <p className="text-sm text-muted-foreground">“{r.reason}” · {new Date(r.created_at).toLocaleDateString("en-IN")}</p>
              {r.maker_note && <p className="text-sm">Reply: {r.maker_note}</p>}
            </div>
            <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold">{RETURN_LABEL[r.status]}</span>
            {r.status === "requested" && <div className="flex gap-2"><Button size="sm" onClick={() => setStatus(r.id, "approved")}>Approve</Button><Button size="sm" variant="outline" onClick={() => setStatus(r.id, "declined")}>Decline</Button></div>}
            {r.status === "approved" && <Button size="sm" variant="outline" onClick={() => setStatus(r.id, "refunded")}>Mark refunded</Button>}
          </li>
        ))}
        {!data.length && <li className="rounded-lg border border-dashed p-8 text-center text-muted-foreground">No return requests.</li>}
      </ul>
    </section>
  );
}
