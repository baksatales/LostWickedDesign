import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { productImage, type Product } from "@/lib/catalog";
import { formatINR } from "@/lib/pricing";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";

export function ProductCard({ p, reasons }: { p: Product; reasons?: string[] }) {
  const { add } = useCart();
  const img = productImage(p);
  const low = p.stock > 0 && p.stock <= 3; // real stock only: honest scarcity
  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border bg-card shadow-soft transition-transform hover:-translate-y-1 animate-rise">
      <Link to="/product/$id" params={{ id: p.id }} className="relative block aspect-square overflow-hidden bg-secondary">
        <img src={img} alt={p.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <span className="absolute left-3 top-3 rounded-full bg-card/95 px-3 py-1 text-xs font-semibold">Handmade</span>
        {low && <span className="absolute right-3 top-3 rounded-full bg-coral px-3 py-1 text-xs font-bold text-foreground">Only {p.stock} left</span>}
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-5">
        <Link to="/makers/$id" params={{ id: p.maker_id }} className="eyebrow hover:text-primary">by {p.maker_name}</Link>
        <Link to="/product/$id" params={{ id: p.id }}><h3 className="text-2xl">{p.name}</h3></Link>
        {reasons && (
          <ul className="space-y-1 text-sm text-muted-foreground">
            {reasons.map((r) => <li key={r} className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />{r}</li>)}
          </ul>
        )}
        <div className="mt-auto flex items-center justify-between pt-3">
          <span className="text-xl font-bold">{formatINR(p.price_inr)}</span>
          <Button size="sm" disabled={p.stock <= 0}
            onClick={() => { add({ productId: p.id, name: p.name, price: p.price_inr, imageUrl: img, maker: p.maker_name }); toast.success(`${p.name} added to your bag`); }}>
            {p.stock <= 0 ? "Sold out" : <><Plus /> Add to bag</>}
          </Button>
        </div>
      </div>
    </article>
  );
}
