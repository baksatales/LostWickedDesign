import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

export function LeadForm({ kind, cta, contactLabel = "WhatsApp number", withDetails, className, dark }: {
  kind: "circle" | "table" | "corporate"; cta: string; contactLabel?: string; withDetails?: string; className?: string; dark?: boolean;
}) {
  const [f, setF] = useState({ name: "", contact: "", details: "" });
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  if (done) return <p className={cn("rounded-xl p-4 font-semibold", dark ? "bg-background/10" : "bg-secondary")}>Thank you — you’re on the list. We’ll be in touch.</p>;
  return (
    <form className={cn("grid gap-3", className)} onSubmit={async (e) => {
      e.preventDefault(); setBusy(true);
      const { error } = await supabase.from("leads").insert({ kind, name: f.name.trim(), contact: f.contact.trim(), details: f.details.trim() || null });
      setBusy(false);
      if (error) toast.error("Please check your details and try again."); else setDone(true);
    }}>
      <div className="grid gap-3 sm:grid-cols-2">
        <Input required maxLength={100} placeholder="Your name" aria-label="Your name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} className="bg-card text-foreground" />
        <Input required minLength={5} maxLength={120} placeholder={contactLabel} aria-label={contactLabel} value={f.contact} onChange={(e) => setF({ ...f, contact: e.target.value })} className="bg-card text-foreground" />
      </div>
      {withDetails && <Textarea maxLength={1000} placeholder={withDetails} aria-label={withDetails} value={f.details} onChange={(e) => setF({ ...f, details: e.target.value })} className="bg-card text-foreground" />}
      <Button type="submit" variant="cta" disabled={busy}>{busy ? "Sending…" : cta}</Button>
    </form>
  );
}
