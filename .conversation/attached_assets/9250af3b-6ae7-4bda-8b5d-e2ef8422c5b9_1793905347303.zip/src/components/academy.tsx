import { Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { PlayCircle, Radio, Users } from "lucide-react";
import type { Course } from "@/lib/queries";
import { formatINR } from "@/lib/pricing";
import { bookCourse } from "@/lib/academy.functions";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

export function CourseCard({ c, onBook }: { c: Course; onBook: (c: Course) => void }) {
  const left = c.seats > 0 ? c.seats - c.booked : null;
  const full = left !== null && left <= 0;
  return (
    <article className="flex flex-col rounded-2xl border bg-card p-6 shadow-soft">
      <span className={cn("inline-flex w-fit items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold", c.format === "live" ? "bg-primary/10 text-primary" : "bg-teal-soft text-teal")}>
        {c.format === "live" ? <Radio className="h-3.5 w-3.5" /> : <PlayCircle className="h-3.5 w-3.5" />}{c.format === "live" ? "Live workshop" : "Recorded class"}
      </span>
      <h3 className="mt-4 text-2xl">{c.title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">by {c.creator_name} · {c.schedule}</p>
      <p className="mt-3 flex-1">{c.description}</p>
      <div className="mt-5 flex items-center justify-between gap-3">
        <div>
          <p className="font-serif text-2xl">{formatINR(c.price_inr)}</p>
          {left !== null && <p className={cn("flex items-center gap-1 text-xs font-semibold", left <= 5 ? "text-warning" : "text-muted-foreground")}><Users className="h-3.5 w-3.5" />{full ? "Sold out" : `${left} of ${c.seats} seats left`}</p>}
        </div>
        <Button variant="cta" disabled={full} onClick={() => onBook(c)}>{c.format === "live" ? "Book a seat" : "Get the class"}</Button>
      </div>
    </article>
  );
}

export function BookingDialog({ course, onClose }: { course: Course | null; onClose: () => void }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const book = useServerFn(bookCourse);
  const [f, setF] = useState({ number: "4242 4242 4242 4242", expiry: "12/30", cvc: "123", name: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  return (
    <Dialog open={!!course} onOpenChange={(o) => { if (!o) { onClose(); setErr(null); } }}>
      <DialogContent>
        {course && (
          <>
            <DialogHeader><DialogTitle className="font-serif text-2xl">{course.title}</DialogTitle><DialogDescription>{course.schedule} · {formatINR(course.price_inr)}</DialogDescription></DialogHeader>
            {!user ? (
              <div className="space-y-3"><p>Sign in to book — it takes a few seconds.</p><Button asChild variant="cta" className="w-full"><Link to="/auth">Sign in to continue</Link></Button></div>
            ) : (
              <form className="space-y-3" onSubmit={async (e) => {
                e.preventDefault(); setBusy(true); setErr(null);
                try {
                  const r = await book({ data: { courseId: course.id, card: f } });
                  if (!r.ok) setErr(r.error);
                  else { toast.success(`You’re booked on “${r.title}”`); qc.invalidateQueries({ queryKey: ["courses"] }); qc.invalidateQueries({ queryKey: ["my-classes"] }); onClose(); }
                } catch { setErr("Something went wrong. You were not charged."); }
                setBusy(false);
              }}>
                <p className="rounded-md bg-secondary p-3 text-xs">Test payment — no real money moves. 4242 4242 4242 4242 succeeds, 4000 0000 0000 0002 is declined.</p>
                <div className="space-y-1"><Label htmlFor="bn">Card number</Label><Input id="bn" value={f.number} onChange={(e) => setF({ ...f, number: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1"><Label htmlFor="be">Expiry</Label><Input id="be" value={f.expiry} onChange={(e) => setF({ ...f, expiry: e.target.value })} /></div>
                  <div className="space-y-1"><Label htmlFor="bc">Security code</Label><Input id="bc" value={f.cvc} onChange={(e) => setF({ ...f, cvc: e.target.value })} /></div>
                </div>
                <div className="space-y-1"><Label htmlFor="bnm">Name on card</Label><Input id="bnm" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
                {err && <p role="alert" className="text-sm font-semibold text-destructive">{err}</p>}
                <Button type="submit" variant="cta" className="w-full" disabled={busy}>{busy ? "Booking…" : `Pay ${formatINR(course.price_inr)}`}</Button>
              </form>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

