import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import logo from "@/assets/catalog/LOGO_FULL.webp.asset.json";
import { productImage, type Product } from "@/lib/catalog";
import { formatINR } from "@/lib/pricing";
import type { Maker } from "@/lib/queries";
import { MakerAvatar } from "@/components/maker-card";

// Claude's opening Baksa: the logo artwork itself is the trunk. It is drawn twice,
// clipped into lid and body; the lid tilts back and three story cards rise out.
export function BaksaTrunk({ maker, product }: { maker?: Maker | undefined; product?: Product | undefined }) {
  const [open, setOpen] = useState(false);
  useEffect(() => { const t = setTimeout(() => setOpen(true), 600); return () => clearTimeout(t); }, []);
  return (
    <div>
      <div className={`stage ${open ? "open" : ""}`}>
        <div className="trunk">
          <div className="cards">
            {maker ? (
              <Link to="/makers/$id" params={{ id: maker.id }} className="scard">
                <MakerAvatar m={maker} className="absolute inset-0 h-full w-full" />
                <div className="cap"><b>Maker story</b>{maker.brand}{maker.tagline ? `: ${maker.tagline}` : ""}</div>
              </Link>
            ) : <span />}
            {product ? (
              <Link to="/product/$id" params={{ id: product.id }} className="scard">
                <img src={productImage(product)} alt={product.name} className="absolute inset-0 h-full w-full object-cover" />
                <div className="cap"><b>From {product.maker_name}</b>{product.name}, {formatINR(product.price_inr)}</div>
              </Link>
            ) : <span />}
            <Link to="/finder" className="scard flex flex-col bg-band p-[9%]">
              <span className="block font-serif text-[clamp(1rem,2vw,1.6rem)] leading-tight">Not sure what to give?</span>
              <span className="mt-1 block text-[0.7rem] text-gold-light">4 quick questions</span>
            </Link>
          </div>
          <div className="inside" />
          <img className="body" src={logo.url} alt="Baksa Tales, Dil Se Duniya Tak" />
          <img className="lid" src={logo.url} alt="" />
        </div>
      </div>
      <div className="mt-3 flex justify-center">
        <button onClick={() => setOpen((o) => !o)} className="text-sm font-semibold text-muted-foreground underline underline-offset-4 hover:text-primary">
          {open ? "Close the baksa" : "Open the baksa"}
        </button>
      </div>
    </div>
  );
}
