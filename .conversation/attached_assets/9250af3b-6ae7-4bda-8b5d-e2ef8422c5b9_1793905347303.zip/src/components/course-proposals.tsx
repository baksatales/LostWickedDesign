import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { formatINR } from "@/lib/pricing";
import type { Course } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { StatusPill } from "@/components/dashboard";

export function CourseProposals({ userId, brand }: { userId: string; brand: string }) {
  const qc = useQueryClient();
  const empty = { title: "", description: "", format: "live" as "live" | "recorded", schedule: "", price: "", seats: "20" };
  const [f, setF] = useState(empty);
  const mine = useQuery({
    queryKey: ["my-courses", userId],
    queryFn: async () => {
      const { data, error } = await supabase.from("courses").select("*").eq("maker_id", userId).order("created_at", { ascending: false });
      if (error) throw error; return data as Course[];
    },
  });
  const enrol = useQuery({
    queryKey: ["my-course-enrolments", userId],
    queryFn: async () => (await supabase.from("course_enrolments").select("course_id, creator_share_inr")).data ?? [],
  });
  const earned = (enrol.data ?? []).reduce((a, e) => a + Number(e.creator_share_inr), 0);
  return (
    <section className="mt-14">
      <p className="eyebrow">Makers’ Academy</p>
      <h2 className="mt-2 text-3xl">My classes</h2>
      <p className="mt-1 text-muted-foreground">Propose → we review → we help you get it ready → we list it. Your share of class sales so far: <strong className="text-foreground">{formatINR(earned)}</strong></p>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <form className="space-y-4 rounded-2xl border bg-card p-6" onSubmit={async (e) => {
          e.preventDefault();
          const { error } = await supabase.from("courses").insert({
            maker_id: userId, creator_name: brand || "Baksa maker", title: f.title.trim(), description: f.description.trim(), format: f.format,
            schedule: f.schedule.trim(), price_inr: Math.round(Number(f.price)), seats: f.format === "live" ? Math.max(1, Number(f.seats) || 1) : 0,
          });
          if (error) { toast.error("Please check the details and try again."); return; }
          toast.success("Sent for review"); setF(empty); qc.invalidateQueries({ queryKey: ["my-courses"] });
        }}>
          <div className="flex gap-2">{(["live", "recorded"] as const).map((k) => (
            <button type="button" key={k} aria-pressed={f.format === k} onClick={() => setF({ ...f, format: k })} className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${f.format === k ? "border-foreground bg-foreground text-background" : ""}`}>{k === "live" ? "Live workshop" : "Recorded class"}</button>
          ))}</div>
          <div className="space-y-1.5"><Label htmlFor="ct">Title</Label><Input id="ct" required maxLength={120} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="cd">What will people learn?</Label><Textarea id="cd" required maxLength={800} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="cs">{f.format === "live" ? "Proposed date and time" : "Length, e.g. 5 short lessons"}</Label><Input id="cs" required maxLength={120} value={f.schedule} onChange={(e) => setF({ ...f, schedule: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label htmlFor="cp">Price (₹)</Label><Input id="cp" type="number" min={1} required value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></div>
            {f.format === "live" && <div className="space-y-1.5"><Label htmlFor="cse">Seats</Label><Input id="cse" type="number" min={1} value={f.seats} onChange={(e) => setF({ ...f, seats: e.target.value })} /></div>}
          </div>
          <Button type="submit" className="w-full">Send for review</Button>
        </form>
        <ul className="space-y-3">
          {(mine.data ?? []).map((c) => (
            <li key={c.id} className="rounded-2xl border bg-card p-4">
              <div className="flex items-start justify-between gap-3"><div><p className="font-semibold">{c.title}</p><p className="text-sm text-muted-foreground">{c.format === "live" ? `${c.booked}/${c.seats} seats` : `${c.booked} sold`} · {formatINR(c.price_inr)}</p></div><StatusPill status={c.status} /></div>
              {c.review_note && <p className="mt-2 text-sm text-warning">Note from Baksa: {c.review_note}</p>}
            </li>
          ))}
          {!mine.data?.length && <li className="rounded-2xl border border-dashed p-8 text-center text-muted-foreground">No classes proposed yet.</li>}
        </ul>
      </div>
    </section>
  );
}
