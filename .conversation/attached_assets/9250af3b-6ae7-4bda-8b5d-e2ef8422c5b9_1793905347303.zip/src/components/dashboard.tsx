import { cn } from "@/lib/utils";

const STATUS: Record<string, string> = {
  pending: "bg-accent text-warning",
  approved: "bg-teal-soft text-success",
  rejected: "bg-destructive/10 text-destructive",
};
const LABEL: Record<string, string> = { pending: "In review", approved: "Live", rejected: "Changes needed" };

export function StatusPill({ status }: { status: string }) {
  return <span className={cn("rounded-full px-3 py-1 font-slab text-xs", STATUS[status])}>{LABEL[status] ?? status}</span>;
}

export function StatTile({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className={cn("rounded-lg border p-5", accent ? "bg-band text-teal-foreground" : "bg-card")}>
      <p className={cn("font-slab text-xs uppercase tracking-widest", accent ? "opacity-80" : "text-muted-foreground")}>{label}</p>
      <p className="mt-2 text-3xl">{value}</p>
    </div>
  );
}
