import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { settingsQuery } from "@/lib/queries";
import { breakEven, formatINR, pieceProfit } from "@/lib/pricing";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const FIELDS = [
  ["price", "Selling price (₹)"], ["materials", "Materials per piece (₹)"], ["labour", "Your time per piece (₹)"],
  ["packaging", "Packaging (₹)"], ["shipping", "Shipping you pay (₹)"], ["fixed", "Monthly fixed costs — rent, tools (₹)"],
] as const;

export function GrowthStudio() {
  const { data: s } = useQuery(settingsQuery);
  const [v, setV] = useState({ price: "1500", materials: "300", labour: "250", packaging: "60", shipping: "90", fixed: "8000" });
  const n = (k: keyof typeof v) => Math.max(0, Number(v[k]) || 0);
  const fees = s ?? { commissionPct: 12, gatewayFeePct: 2 };
  const r = pieceProfit({ price: n("price"), materials: n("materials"), labour: n("labour"), packaging: n("packaging"), shipping: n("shipping") }, fees);
  const be = breakEven(n("fixed"), r.profit);
  const health = r.margin >= 35 ? ["Healthy", "text-success"] : r.margin >= 15 ? ["Thin", "text-warning"] : ["Losing money", "text-destructive"];
  return (
    <section className="mt-14">
      <p className="eyebrow">Growth Studio</p>
      <h2 className="mt-2 text-3xl">Price with confidence</h2>
      <p className="mt-1 text-muted-foreground">Change any number and the answers update. Nothing here is saved or shared.</p>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="grid gap-4 rounded-2xl border bg-card p-6 sm:grid-cols-2">
          {FIELDS.map(([k, l]) => (
            <div key={k} className="space-y-1.5"><Label htmlFor={`g-${k}`}>{l}</Label><Input id={`g-${k}`} type="number" min={0} value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} /></div>
          ))}
        </div>
        <div className="rounded-2xl bg-band p-6 text-teal-foreground">
          <dl className="grid grid-cols-2 gap-5">
            <div><dt className="text-sm opacity-75">Baksa fees ({fees.commissionPct + fees.gatewayFeePct}%)</dt><dd className="font-serif text-2xl">{formatINR(r.fees)}</dd></div>
            <div><dt className="text-sm opacity-75">Your costs</dt><dd className="font-serif text-2xl">{formatINR(r.costs)}</dd></div>
            <div><dt className="text-sm opacity-75">You keep per piece</dt><dd className="font-serif text-3xl">{formatINR(r.profit)}</dd></div>
            <div><dt className="text-sm opacity-75">Margin</dt><dd className="font-serif text-3xl">{r.margin}% <span className={cn("rounded-full bg-card px-2 py-0.5 align-middle font-sans text-xs font-bold", health[1])}>{health[0]}</span></dd></div>
            <div><dt className="text-sm opacity-75">Pieces a month to cover fixed costs</dt><dd className="font-serif text-2xl">{Number.isFinite(be) ? be : "—"}</dd></div>
            <div><dt className="text-sm opacity-75">Price for a 35% margin</dt><dd className="font-serif text-2xl">{r.suggested ? formatINR(r.suggested) : "—"}</dd></div>
          </dl>
        </div>
      </div>
    </section>
  );
}
