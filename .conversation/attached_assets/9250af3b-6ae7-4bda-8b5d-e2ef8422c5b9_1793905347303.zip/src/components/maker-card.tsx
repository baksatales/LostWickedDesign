import { Link } from "@tanstack/react-router";
import { BadgeCheck } from "lucide-react";
import { imageFor } from "@/lib/catalog";
import type { Maker } from "@/lib/queries";
import { MakerBadges } from "@/components/badge-pill";

export function MakerAvatar({ m, className = "h-full w-full" }: { m: Pick<Maker, "brand" | "image_key">; className?: string }) {
  const img = imageFor(m.image_key);
  if (img) return <img src={img} alt={m.brand} loading="lazy" className={`${className} object-cover`} />;
  return (
    <div className={`${className} flex items-center justify-center bg-secondary font-serif text-5xl text-primary`}>
      {m.brand.slice(0, 1)}
    </div>
  );
}

// Identifiable faces and names build liking and trust (identifiable-victim / liking effects).
export function MakerCard({ m }: { m: Maker }) {
  return (
    <Link to="/makers/$id" params={{ id: m.id }} className="group block overflow-hidden rounded-2xl border bg-card shadow-soft transition-transform hover:-translate-y-1">
      <div className="aspect-[4/3] overflow-hidden"><MakerAvatar m={m} className="h-full w-full transition-transform duration-700 group-hover:scale-105" /></div>
      <div className="p-5">
        <div className="flex items-center gap-2">
          <h3 className="text-2xl">{m.brand}</h3>
          {m.is_founding && <BadgeCheck className="h-5 w-5 text-primary" aria-label="Founding maker" />}
        </div>
        <p className="mt-1 text-sm text-muted-foreground">{m.craft || "Handmade in India"}</p>
        <MakerBadges makerId={m.id} className="mt-3" />
        {m.tagline && <p className="mt-3 font-serif text-lg italic">“{m.tagline}”</p>}
      </div>
    </Link>
  );
}
