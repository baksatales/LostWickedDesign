import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export type SitePage = {
  id: string; slug: string; title: string; body: string; kind: string;
  footer_column: string | null; sort: number; published: boolean; updated_at: string;
};

export const footerPagesQuery = {
  queryKey: ["footer-pages"],
  queryFn: async () => {
    const { data } = await supabase.from("site_pages").select("slug,title,footer_column,sort").eq("published", true).not("footer_column", "is", null).order("sort");
    return data ?? [];
  },
};

const blank = { slug: "", title: "", body: "", kind: "page", footer_column: "Help", sort: 0, published: true };

export function PagesManager() {
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["admin-pages"], queryFn: async () => ((await supabase.from("site_pages").select("*").order("footer_column").order("sort")).data ?? []) as SitePage[] });
  const [edit, setEdit] = useState<Partial<SitePage> | null>(null);

  async function save() {
    if (!edit) return;
    const slug = (edit.slug || edit.title || "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    if (!slug || !edit.title) { toast.error("Add a title"); return; }
    const row = { slug, title: edit.title, body: edit.body ?? "", kind: edit.kind ?? "page", footer_column: edit.footer_column?.trim() || null, sort: Number(edit.sort) || 0, published: edit.published ?? true, updated_at: new Date().toISOString() };
    const { error } = edit.id ? await supabase.from("site_pages").update(row).eq("id", edit.id) : await supabase.from("site_pages").insert(row);
    if (error) { toast.error(error.message); return; }
    toast.success("Saved"); setEdit(null);
    qc.invalidateQueries({ queryKey: ["admin-pages"] }); qc.invalidateQueries({ queryKey: ["footer-pages"] });
  }
  async function remove(id: string) {
    if (!confirm("Delete this page?")) return;
    await supabase.from("site_pages").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["admin-pages"] }); qc.invalidateQueries({ queryKey: ["footer-pages"] });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Pages and blog posts. Give one a footer column (e.g. "Help") to show its link in the footer.</p>
        <Button onClick={() => setEdit({ ...blank })}>New page or post</Button>
      </div>
      {edit && (
        <div className="space-y-3 rounded-lg border bg-card p-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <Input placeholder="Title" value={edit.title ?? ""} onChange={(e) => setEdit({ ...edit, title: e.target.value })} />
            <Input placeholder="Web address (auto from title)" value={edit.slug ?? ""} onChange={(e) => setEdit({ ...edit, slug: e.target.value })} />
            <select className="h-10 rounded-md border bg-background px-3 text-sm" value={edit.kind} onChange={(e) => setEdit({ ...edit, kind: e.target.value })}>
              <option value="page">Page</option><option value="blog">Blog post</option>
            </select>
            <Input placeholder="Footer column (blank = not in footer)" value={edit.footer_column ?? ""} onChange={(e) => setEdit({ ...edit, footer_column: e.target.value })} />
            <Input type="number" placeholder="Order" value={edit.sort ?? 0} onChange={(e) => setEdit({ ...edit, sort: Number(e.target.value) })} />
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={edit.published ?? true} onChange={(e) => setEdit({ ...edit, published: e.target.checked })} /> Published</label>
          </div>
          <Textarea rows={12} placeholder="Write here. Blank lines start new paragraphs; lines starting with ## become headings." value={edit.body ?? ""} onChange={(e) => setEdit({ ...edit, body: e.target.value })} />
          <div className="flex gap-2"><Button onClick={save}>Save</Button><Button variant="ghost" onClick={() => setEdit(null)}>Cancel</Button></div>
        </div>
      )}
      <ul className="divide-y rounded-lg border bg-card">
        {(data ?? []).map((p) => (
          <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 p-4">
            <span><b>{p.title}</b> <span className="text-xs text-muted-foreground">/p/{p.slug} · {p.kind === "blog" ? "Blog" : "Page"}{p.footer_column ? ` · footer: ${p.footer_column}` : ""}{p.published ? "" : " · draft"}</span></span>
            <span className="flex gap-2"><Button size="sm" variant="outline" onClick={() => setEdit(p)}>Edit</Button><Button size="sm" variant="ghost" onClick={() => remove(p.id)}>Delete</Button></span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function PageBody({ body }: { body: string }) {
  return (
    <div className="mt-8 space-y-5 text-lg leading-relaxed">
      {body.split(/\n\s*\n/).map((b, i) => b.startsWith("## ")
        ? <h2 key={i} className="pt-4 text-3xl">{b.slice(3)}</h2>
        : <p key={i} className="whitespace-pre-line">{b}</p>)}
    </div>
  );
}
