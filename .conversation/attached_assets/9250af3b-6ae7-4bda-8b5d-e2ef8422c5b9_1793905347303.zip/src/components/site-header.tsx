import { useQuery } from "@tanstack/react-query";
import { footerPagesQuery } from "@/components/site-pages";
import { Link, useNavigate, type LinkProps } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";
import logo from "@/assets/catalog/LOGO_FULL.webp.asset.json";
import tile from "@/assets/catalog/LOGO_TILE.webp.asset.json";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";

const navCls = "text-sm font-semibold text-foreground/75 hover:text-primary transition-colors";

export function SiteHeader() {
  const { user, roles, signOut } = useAuth();
  const { lines } = useCart();
  const navigate = useNavigate();
  const count = lines.reduce((a, l) => a + l.quantity, 0);
  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-5">
        <Link to="/" className="shrink-0"><img src={logo.url} alt="Baksa Tales" className="h-9 w-auto" /></Link>
        <nav className="hidden items-center gap-4 xl:gap-5 lg:flex">
          <Link to="/finder" className={navCls} activeProps={{ className: "text-primary" }}>Gift finder</Link>
          <Link to="/shop" className={navCls} activeProps={{ className: "text-primary" }}>All gifts</Link>
          <Link to="/makers" className={navCls} activeProps={{ className: "text-primary" }}>Makers</Link>
          <Link to="/corporate" className={navCls} activeProps={{ className: "text-primary" }}>Corporate</Link>
          <Link to="/academy" className={navCls} activeProps={{ className: "text-primary" }}>Makers’ Academy</Link>
          {roles.includes("maker") ? <Link to="/studio" className={navCls} activeProps={{ className: "text-primary" }}>My studio</Link> : !roles.includes("admin") && <Link to="/sell" className={navCls} activeProps={{ className: "text-primary" }}>Sell with Baksa</Link>}
          {roles.includes("admin") && <Link to="/admin" className={navCls} activeProps={{ className: "text-primary" }}>Admin</Link>}
          {user && <Link to="/orders" className={navCls} activeProps={{ className: "text-primary" }}>My orders</Link>}
          {user && <Link to="/classes" className={navCls} activeProps={{ className: "text-primary" }}>My classes</Link>}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <Button asChild variant="cta" size="sm" className="hidden lg:inline-flex"><Link to="/finder">Find a gift</Link></Button>
          <Link to="/bag" className="relative inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-secondary" aria-label={`Bag, ${count} items`}>
            <ShoppingBag className="h-5 w-5" />
            {count > 0 && <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground animate-pop" key={count}>{count}</span>}
          </Link>
          {user ? (
            <Button variant="ghost" size="sm" onClick={async () => { await signOut(); navigate({ to: "/" }); }}>Sign out</Button>
          ) : (
            <Button asChild variant="outline" size="sm"><Link to="/auth">Sign in</Link></Button>
          )}
        </div>
      </div>
      <nav className="flex gap-4 overflow-x-auto border-t px-5 py-2 lg:hidden">
        <Link to="/finder" className={navCls}>Gift finder</Link>
        <Link to="/shop" className={navCls}>All gifts</Link>
        <Link to="/makers" className={navCls}>Makers</Link>
        <Link to="/corporate" className={navCls}>Corporate</Link>
        <Link to="/academy" className={navCls}>Academy</Link>
        {roles.includes("maker") ? <Link to="/studio" className={navCls}>Studio</Link> : <Link to="/sell" className={navCls}>Sell</Link>}
        {roles.includes("admin") && <Link to="/admin" className={navCls}>Admin</Link>}
        {user && <Link to="/orders" className={navCls}>Orders</Link>}
        {user && <Link to="/classes" className={navCls}>Classes</Link>}
      </nav>
    </header>
  );
}

const footCols: { h: string; links: { to: NonNullable<LinkProps["to"]>; l: string }[] }[] = [
  { h: "Discover", links: [{ to: "/makers", l: "Makers" }, { to: "/finder", l: "Gift finder" }, { to: "/shop", l: "The BT Edit" }] },
  { h: "For businesses", links: [{ to: "/corporate", l: "Corporate gifting" }, { to: "/sell", l: "Sell with Baksa" }] },
  { h: "Learn", links: [{ to: "/academy", l: "Makers’ Academy" }, { to: "/", l: "The Makers’ Table" }] },
  { h: "Your account", links: [{ to: "/orders", l: "My orders & returns" }, { to: "/classes", l: "My classes" }, { to: "/studio", l: "Maker studio" }] },
];

export function SiteFooter() {
  const extra = useQuery(footerPagesQuery).data ?? [];
  const cols = footCols.map((c) => ({ h: c.h, links: c.links.map((l) => ({ ...l, slug: "" })) }));
  for (const pg of extra) {
    let col = cols.find((c) => c.h === pg.footer_column);
    if (!col) { col = { h: pg.footer_column!, links: [] }; cols.push(col); }
    col.links.push({ to: "/p/$slug", l: pg.title, slug: pg.slug } as never);
  }
  return (
    <footer className="mt-28 bg-ink text-secondary">
      <div className="mx-auto max-w-6xl px-5 pb-10 pt-16">
        <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-[1.5fr_repeat(5,1fr)]">
          <div>
            <img src={tile.url} alt="Baksa Tales, Dil Se Duniya Tak" className="w-[min(240px,100%)] rounded" />
            <p className="mt-5 font-deva text-2xl text-gold-light" lang="hi">दिल से दुनिया तक</p>
            <p className="mt-3 max-w-xs font-serif text-lg italic leading-snug opacity-90">Storytelling is the identity. Discovery is the experience. Commerce is the outcome.</p>
          </div>
          {cols.map((c) => (
            <div key={c.h}>
              <h4 className="font-serif text-xl text-gold-light">{c.h}</h4>
              <ul className="mt-4 space-y-3">{c.links.map((l) => <li key={l.l}><Link to={l.to as never} {...(l.slug ? { params: { slug: l.slug } as never } : {})} className="text-sm opacity-80 transition hover:text-gold-light hover:opacity-100">{l.l}</Link></li>)}</ul>
            </div>
          ))}
        </div>
        <div className="mt-14 flex flex-col gap-2 border-t border-secondary/15 pt-6 text-xs opacity-60 md:flex-row md:justify-between">
          <p>© {new Date().getFullYear()} Baksa Tales</p>
          <p>Payments run in test mode.</p>
        </div>
      </div>
    </footer>
  );
}

export function RoleGate({ role, children }: { role: "admin" | "maker"; children: React.ReactNode }) {
  const { roles, loading } = useAuth();
  if (loading) return <div className="mx-auto max-w-6xl px-5 py-24 text-muted-foreground">Loading…</div>;
  if (!roles.includes(role)) return null;
  return <>{children}</>;
}
