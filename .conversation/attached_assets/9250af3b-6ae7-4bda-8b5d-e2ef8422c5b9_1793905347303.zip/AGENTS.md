<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules
- Money split (commission, payment fee, seller earnings) lives only in `src/lib/pricing.ts`; checkout server fn computes it from DB prices so the browser can't set amounts.
- Orders are written only by the `record_order` DB function (service role) after the test gateway in `src/lib/test-payment.ts` approves; it decrements stock atomically.
- Roles live in `user_roles` (admin/maker/shopper); product review status can only be changed by admins, enforced by the `guard_product_review` trigger.
- Gift finder scoring is the pure `recommend()` in `src/lib/catalog.ts`; covered by `src/test/marketplace-rules.test.ts`.
- Public maker profiles live in `makers` (id = maker's user id); the signup trigger `handle_new_user` creates one for every new maker, founding makers are flagged `is_founding` and can't be edited by makers.
- Maker badges are data (`badges` + `maker_badges`), admin-only writes; render via `MakerBadges` so new badges need no code.
- Academy seats are booked only through `bookCourse` server fn → service-role `record_enrolment` (seat check + split from `splitCourse`).
- Editable home copy lives in `site_content` (key → JSON block), edited from the admin "Home page" tab; pages fall back to defaults.
- Circle/waitlist/corporate sign-ups go to `leads` (anyone can insert, only admins read).
- Returns go through the `request_return` DB function (ownership + 7-day window); makers/admins update `return_requests` via the shared `ReturnsDesk`.
