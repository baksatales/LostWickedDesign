create type public.app_role as enum ('admin','maker','shopper');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  studio_name text,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "own profile read" on public.profiles for select to authenticated using (id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "own profile update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "own roles read" on public.user_roles for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare r text := coalesce(new.raw_user_meta_data->>'role','shopper');
begin
  insert into public.profiles (id, display_name, studio_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)), new.raw_user_meta_data->>'studio_name');
  if r not in ('maker','shopper') then r := 'shopper'; end if;
  insert into public.user_roles (user_id, role) values (new.id, r::public.app_role);
  if r = 'maker' then insert into public.user_roles (user_id, role) values (new.id, 'shopper') on conflict do nothing; end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.claim_admin()
returns boolean language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return false; end if;
  if exists (select 1 from public.user_roles where role = 'admin') then return false; end if;
  insert into public.user_roles (user_id, role) values (auth.uid(), 'admin');
  return true;
end $$;
revoke execute on function public.claim_admin() from public, anon;
grant execute on function public.claim_admin() to authenticated;

create or replace function public.admin_exists()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where role = 'admin')
$$;
grant execute on function public.admin_exists() to anon, authenticated;

create table public.platform_settings (
  id int primary key default 1 check (id = 1),
  commission_pct numeric(5,2) not null default 12,
  gateway_fee_pct numeric(5,2) not null default 2,
  updated_at timestamptz not null default now()
);
grant select on public.platform_settings to anon, authenticated;
grant update on public.platform_settings to authenticated;
grant all on public.platform_settings to service_role;
alter table public.platform_settings enable row level security;
create policy "settings readable" on public.platform_settings for select to anon, authenticated using (true);
create policy "admin updates settings" on public.platform_settings for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
insert into public.platform_settings (id) values (1);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  maker_id uuid not null,
  maker_name text not null default '',
  name text not null check (char_length(name) between 2 and 120),
  description text not null default '',
  price_inr integer not null check (price_inr > 0),
  stock integer not null default 1 check (stock >= 0),
  image_key text,
  image_url text,
  recipients text[] not null default '{}',
  occasions text[] not null default '{}',
  feelings text[] not null default '{}',
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  review_note text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
grant select on public.products to anon;
grant select, insert, update, delete on public.products to authenticated;
grant all on public.products to service_role;
alter table public.products enable row level security;
create policy "approved visible" on public.products for select to anon, authenticated using (status = 'approved');
create policy "maker sees own" on public.products for select to authenticated using (maker_id = auth.uid());
create policy "admin sees all" on public.products for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "maker submits" on public.products for insert to authenticated with check (maker_id = auth.uid() and public.has_role(auth.uid(),'maker'));
create policy "maker edits own" on public.products for update to authenticated using (maker_id = auth.uid()) with check (maker_id = auth.uid());
create policy "admin reviews" on public.products for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (true);
create policy "maker deletes own unapproved" on public.products for delete to authenticated using (maker_id = auth.uid() and status <> 'approved');

create or replace function public.guard_product_review()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.has_role(auth.uid(),'admin') or auth.role() = 'service_role' then
    if tg_op = 'UPDATE' and new.status is distinct from old.status then new.reviewed_at := now(); end if;
    return new;
  end if;
  new.status := 'pending'; new.review_note := null; new.reviewed_at := null;
  if tg_op = 'UPDATE' then new.maker_id := old.maker_id; end if;
  return new;
end $$;
create trigger products_guard before insert or update on public.products for each row execute function public.guard_product_review();

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  shopper_id uuid not null,
  subtotal_inr numeric(12,2) not null,
  commission_inr numeric(12,2) not null,
  gateway_fee_inr numeric(12,2) not null,
  seller_earnings_inr numeric(12,2) not null,
  commission_pct numeric(5,2) not null,
  gateway_fee_pct numeric(5,2) not null,
  payment_ref text not null,
  card_last4 text not null,
  status text not null default 'paid',
  recipient_name text not null,
  ship_address text not null,
  gift_note text,
  quiz_answers jsonb,
  created_at timestamptz not null default now()
);
grant select on public.orders to authenticated;
grant all on public.orders to service_role;
alter table public.orders enable row level security;
create policy "shopper reads own orders" on public.orders for select to authenticated using (shopper_id = auth.uid() or public.has_role(auth.uid(),'admin'));

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  maker_id uuid not null,
  product_name text not null,
  unit_price_inr integer not null,
  quantity integer not null check (quantity > 0),
  line_total_inr numeric(12,2) not null,
  commission_inr numeric(12,2) not null,
  gateway_fee_inr numeric(12,2) not null,
  seller_earnings_inr numeric(12,2) not null,
  created_at timestamptz not null default now()
);
grant select on public.order_items to authenticated;
grant all on public.order_items to service_role;
alter table public.order_items enable row level security;
create policy "item visibility" on public.order_items for select to authenticated using (
  maker_id = auth.uid() or public.has_role(auth.uid(),'admin')
  or exists (select 1 from public.orders o where o.id = order_id and o.shopper_id = auth.uid()));

create or replace function public.record_order(p_order jsonb, p_items jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare oid uuid; it jsonb; left_stock int;
begin
  insert into public.orders (shopper_id, subtotal_inr, commission_inr, gateway_fee_inr, seller_earnings_inr,
    commission_pct, gateway_fee_pct, payment_ref, card_last4, recipient_name, ship_address, gift_note, quiz_answers)
  values ((p_order->>'shopper_id')::uuid, (p_order->>'subtotal')::numeric, (p_order->>'commission')::numeric,
    (p_order->>'gateway_fee')::numeric, (p_order->>'seller_earnings')::numeric, (p_order->>'commission_pct')::numeric,
    (p_order->>'gateway_fee_pct')::numeric, p_order->>'payment_ref', p_order->>'card_last4',
    p_order->>'recipient_name', p_order->>'ship_address', p_order->>'gift_note', p_order->'quiz_answers')
  returning id into oid;
  for it in select * from jsonb_array_elements(p_items) loop
    update public.products set stock = stock - (it->>'quantity')::int
      where id = (it->>'product_id')::uuid and status = 'approved' and stock >= (it->>'quantity')::int
      returning stock into left_stock;
    if not found then raise exception 'OUT_OF_STOCK:%', it->>'product_name'; end if;
    insert into public.order_items (order_id, product_id, maker_id, product_name, unit_price_inr, quantity,
      line_total_inr, commission_inr, gateway_fee_inr, seller_earnings_inr)
    values (oid, (it->>'product_id')::uuid, (it->>'maker_id')::uuid, it->>'product_name', (it->>'unit_price')::int,
      (it->>'quantity')::int, (it->>'line_total')::numeric, (it->>'commission')::numeric,
      (it->>'gateway_fee')::numeric, (it->>'seller_earnings')::numeric);
  end loop;
  return oid;
end $$;
revoke execute on function public.record_order(jsonb, jsonb) from public, anon, authenticated;
grant execute on function public.record_order(jsonb, jsonb) to service_role;

create policy "product images read" on storage.objects for select using (bucket_id = 'product-images');
create policy "makers upload own images" on storage.objects for insert to authenticated
  with check (bucket_id = 'product-images' and (storage.foldername(name))[1] = auth.uid()::text);

insert into public.products (maker_id, maker_name, name, description, price_inr, stock, image_key, recipients, occasions, feelings, status, reviewed_at) values
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Lotus Pond Candle Set','A set of timeless charm: soy wax lotuses floating in a pond of their own.',2400,6,'t-lotuspond','{parent,partner}','{diwali,housewarming}','{showstopper,heart}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Crimson Lotus Urli','A crimson lotus candle set in a brass urli, ringed with smaller blooms.',1800,9,'t-crimson','{parent,partner}','{diwali,wedding}','{heart,showstopper}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Bouquet with a Message','A candle bouquet that never wilts, with a personalised topper of your words.',2200,10,'t-message','{friend,partner}','{birthday,thanks}','{heart,thoughtful}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Large Teapot Bouquet','A polka-dot teacup brimming with soy wax blooms in every shade of pink.',3200,4,'t-teapot','{parent,friend}','{birthday,housewarming}','{heart,showstopper}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Marigold Urli','Saffron marigolds in a gold-toned urli with a scalloped rim, for festive warmth.',1200,24,'t-marigold','{colleague,friend}','{diwali}','{thoughtful}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Sunflower Trio','Three sculpted sunflowers. Bright, cheerful and impossible to ignore.',1500,12,'t-sunflower','{friend,self}','{birthday,justbecause}','{thoughtful,explorer}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Shell and Bloom','Sea shells and small blooms in soft wax, a quiet piece for slow evenings.',1900,8,'t-shell','{friend,self}','{housewarming,justbecause}','{soother,explorer}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Blue Lotus','A single blue lotus, calm and cool, for a desk or a bedside.',1100,15,'t-bluelotus','{self,colleague}','{thanks,justbecause}','{soother,thoughtful}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Pink Peony Jar','Lush peonies in a frosted jar, a soft-scented thank you.',1400,11,'t-pinkpeony','{friend,colleague,parent}','{thanks,birthday}','{heart,soother}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Succulent Garden','Wax succulents that never need watering, for the friend who forgets.',1300,14,'t-succulents','{friend,colleague,self}','{housewarming,justbecause}','{explorer,thoughtful}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Gajra Candle','Jasmine gajra strands shaped in wax, made for wedding trays.',900,30,'t-gajra','{partner,parent}','{wedding,diwali}','{heart,explorer}','approved',now()),
('00000000-0000-0000-0000-0000000000a1','Tathaastu studio','Starfish Tealights','A set of starfish tealights, little pieces of the coast.',800,20,'t-starfish','{friend,self,colleague}','{justbecause,thanks}','{explorer,soother}','approved',now());