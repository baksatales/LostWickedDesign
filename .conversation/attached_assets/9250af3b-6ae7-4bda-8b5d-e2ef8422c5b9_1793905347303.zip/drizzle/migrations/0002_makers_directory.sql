CREATE TABLE public.makers (
  id uuid PRIMARY KEY,
  brand text NOT NULL,
  craft text NOT NULL DEFAULT '',
  tagline text NOT NULL DEFAULT '',
  bio text NOT NULL DEFAULT '',
  story text NOT NULL DEFAULT '',
  techniques text[] NOT NULL DEFAULT '{}',
  image_key text,
  is_founding boolean NOT NULL DEFAULT false,
  published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.makers TO anon;
GRANT SELECT, UPDATE ON public.makers TO authenticated;
GRANT ALL ON public.makers TO service_role;
ALTER TABLE public.makers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "published makers visible" ON public.makers FOR SELECT TO anon, authenticated USING (published OR id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "maker edits own profile" ON public.makers FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid() AND is_founding = false);
CREATE POLICY "admin edits makers" ON public.makers FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

INSERT INTO public.makers (id, brand, craft, tagline, bio, story, techniques, image_key, is_founding) VALUES
('00000000-0000-0000-0000-0000000000a1','Tathaastu','Hand-shaped soy wax florals','Where craftsmanship meets the art of gifting.','An Olive Green partner. Every Tathaastu piece supports war widows and army wives as they rebuild their lives and become financially independent.',E'Soy wax is shaped petal by petal into lotuses, peonies and sunflowers, then set in brass urlis, teapots and sculpted vessels.\n\nThe collections run from single blooms to candle bouquets that never wilt, sculptural vases and diffusers, and Utsav florals in gold-toned urlis for festive warmth.',ARRAY['Soy wax shaped petal by petal','Brass urlis, teapots and sculpted vessels','Personalised toppers for bouquets'],'t-lotuspond',true),
('00000000-0000-0000-0000-0000000000a2','Mushhk','Botanical oils, mists and salts','Serenity in a bottle.','Mushhk believes beauty lives not in youth but in continuity, in caring for yourself as you are.',E'Its oils, mists, salts and scrubs are made for the ten quiet minutes at either end of a day.\n\nEvery Mushhk product is free of chemicals, preservatives, parabens and artificial fragrance, and is never tested on animals.',ARRAY['Face, night and body oil blends','Essential-oil room mists','Salt soaks and coffee scrubs'],NULL,true),
('00000000-0000-0000-0000-0000000000a3','Svara','Alcohol-free fragrance','A fragrance you wear for how it makes you feel.','Svara sets Indian botanicals on a magnesium oil base, with no alcohol.',E'Each spray carries 9 mg of magnesium and settles into the skin as a small evening ritual.\n\nThe range has four moods: Sandhya for everyday elegance, Ratri for the pulse of the night, Divya for sunlight, and more.',ARRAY['Magnesium oil base','Indian botanicals','No alcohol'],'sv-sandhya',true),
('00000000-0000-0000-0000-0000000000a4','Anirveda','Ayurvedic skincare','Skincare that begins in the Indian kitchen and bathhouse.','Saffron, triphala and ubtan, kept in jars and bottles painted with peacocks and lotus blooms.',E'Anirveda draws on old Indian bath rituals: a bath ubtan, a kumkumadi face pack, a saffron face wash, a triphala night cream, oil pulling and a face mist.\n\nThe jars are beautiful enough to leave out on the shelf, which makes them natural gifts.',ARRAY['Ubtan and kumkumadi recipes','Saffron and triphala','Jars painted with peacocks and lotus blooms'],'an-range',true);

INSERT INTO public.makers (id, brand, craft)
SELECT p.id, coalesce(nullif(p.studio_name,''), p.display_name), '' FROM public.profiles p
WHERE EXISTS (SELECT 1 FROM public.user_roles r WHERE r.user_id = p.id AND r.role = 'maker')
ON CONFLICT (id) DO NOTHING;

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
declare r text := coalesce(new.raw_user_meta_data->>'role','shopper');
begin
  insert into public.profiles (id, display_name, studio_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)), new.raw_user_meta_data->>'studio_name');
  if r not in ('maker','shopper') then r := 'shopper'; end if;
  insert into public.user_roles (user_id, role) values (new.id, r::public.app_role);
  if r = 'maker' then
    insert into public.user_roles (user_id, role) values (new.id, 'shopper') on conflict do nothing;
    insert into public.makers (id, brand) values (new.id, coalesce(nullif(new.raw_user_meta_data->>'studio_name',''), new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1))) on conflict do nothing;
  end if;
  return new;
end $$;

UPDATE public.products SET maker_name = 'Tathaastu' WHERE maker_id = '00000000-0000-0000-0000-0000000000a1';
INSERT INTO public.products (maker_id, maker_name, name, description, price_inr, stock, image_key, recipients, occasions, feelings, status) VALUES
('00000000-0000-0000-0000-0000000000a3','Svara','Svara Sandhya','Everyday elegance in an alcohol-free spray, set on a magnesium oil base with Indian botanicals. 100 ml.',1800,12,'sv-sandhya',ARRAY['partner','friend','self'],ARRAY['birthday','justbecause','thanks'],ARRAY['soother','heart'],'approved'),
('00000000-0000-0000-0000-0000000000a4','Anirveda','The Anirveda Ritual Set','Face wash, ubtan and night cream with saffron and triphala, in jars painted with peacocks and lotus blooms.',3500,8,'an-range',ARRAY['parent','colleague'],ARRAY['diwali','wedding','thanks'],ARRAY['showstopper','heart'],'approved');