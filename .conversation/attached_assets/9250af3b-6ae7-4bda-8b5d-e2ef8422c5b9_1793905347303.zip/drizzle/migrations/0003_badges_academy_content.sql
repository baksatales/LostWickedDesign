-- Badges
create table public.badges (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  label text not null,
  description text not null default '',
  tone text not null default 'sage' check (tone in ('sage','marigold','navy','ember','cream')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.badges to anon, authenticated;
grant insert, update, delete on public.badges to authenticated;
grant all on public.badges to service_role;
alter table public.badges enable row level security;
create policy "badges readable" on public.badges for select to anon, authenticated using (active or public.has_role(auth.uid(),'admin'));
create policy "admin manages badges" on public.badges for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.maker_badges (
  maker_id uuid not null references public.makers(id) on delete cascade,
  badge_id uuid not null references public.badges(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (maker_id, badge_id)
);
grant select on public.maker_badges to anon, authenticated;
grant insert, delete on public.maker_badges to authenticated;
grant all on public.maker_badges to service_role;
alter table public.maker_badges enable row level security;
create policy "maker badges readable" on public.maker_badges for select to anon, authenticated using (true);
create policy "admin assigns badges" on public.maker_badges for insert to authenticated with check (public.has_role(auth.uid(),'admin'));
create policy "admin revokes badges" on public.maker_badges for delete to authenticated using (public.has_role(auth.uid(),'admin'));

insert into public.badges (slug,label,description,tone) values
 ('olive-green','Olive Green Entrepreneur','Studios that support war widows and the families of Indian Army personnel.','sage'),
 ('heritage-craft','Heritage Craft','A traditional technique passed down through generations.','marigold'),
 ('women-led','Women-led Studio','Founded and run by women.','ember');
insert into public.maker_badges (maker_id, badge_id)
 select '00000000-0000-0000-0000-0000000000a1', id from public.badges where slug='olive-green';

-- Academy
alter table public.platform_settings add column academy_share_pct numeric not null default 30;

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  maker_id uuid,
  creator_name text not null,
  title text not null,
  description text not null default '',
  format text not null check (format in ('recorded','live')),
  schedule text not null default '',
  meeting_link text,
  price_inr integer not null check (price_inr > 0),
  seats integer not null default 0 check (seats >= 0),
  booked integer not null default 0 check (booked >= 0),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  review_note text,
  created_at timestamptz not null default now()
);
grant select on public.courses to anon, authenticated;
grant insert, update, delete on public.courses to authenticated;
grant all on public.courses to service_role;
alter table public.courses enable row level security;
create policy "approved courses visible" on public.courses for select to anon, authenticated using (status='approved' or maker_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "maker proposes course" on public.courses for insert to authenticated with check (maker_id = auth.uid() and public.has_role(auth.uid(),'maker') and status='pending' and booked=0);
create policy "maker withdraws pending" on public.courses for delete to authenticated using (maker_id = auth.uid() and status <> 'approved');
create policy "admin manages courses" on public.courses for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.course_enrolments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id),
  shopper_id uuid not null,
  price_inr numeric not null,
  baksa_share_inr numeric not null,
  creator_share_inr numeric not null,
  payment_ref text not null,
  card_last4 text not null,
  created_at timestamptz not null default now(),
  unique (course_id, shopper_id)
);
grant select on public.course_enrolments to authenticated;
grant all on public.course_enrolments to service_role;
alter table public.course_enrolments enable row level security;
create policy "enrolment visibility" on public.course_enrolments for select to authenticated using (
  shopper_id = auth.uid() or public.has_role(auth.uid(),'admin')
  or exists (select 1 from public.courses c where c.id = course_id and c.maker_id = auth.uid()));

create or replace function public.record_enrolment(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_course public.courses;
begin
  select * into v_course from public.courses where id = (p->>'course_id')::uuid and status='approved' for update;
  if not found then raise exception 'COURSE_UNAVAILABLE'; end if;
  if v_course.seats > 0 and v_course.booked >= v_course.seats then raise exception 'SOLD_OUT'; end if;
  insert into public.course_enrolments (course_id, shopper_id, price_inr, baksa_share_inr, creator_share_inr, payment_ref, card_last4)
  values (v_course.id, (p->>'shopper_id')::uuid, (p->>'price')::numeric, (p->>'baksa_share')::numeric, (p->>'creator_share')::numeric, p->>'payment_ref', p->>'card_last4')
  returning id into v_id;
  update public.courses set booked = booked + 1 where id = v_course.id;
  return v_id;
end $$;
revoke execute on function public.record_enrolment(jsonb) from public, anon, authenticated;
grant execute on function public.record_enrolment(jsonb) to service_role;

insert into public.courses (creator_name,title,description,format,schedule,price_inr,seats,status) values
 ('Baksa Tales team','Price your handmade work with confidence','Work out your real cost per piece, your margin, and the number you need to sell each month.','recorded','Watch any time · 6 short lessons',999,0,'approved'),
 ('Baksa Tales team','Tell your brand’s story in 60 seconds','Find the one true story about your work and say it on camera, on a label and to a buyer.','live','Thursday 26 November, 6 pm',1500,25,'approved'),
 ('Baksa Tales team','Photograph your products with a phone','Window light, a plain backdrop and one close-up of the detail that makes your piece special.','recorded','Watch any time · 4 lessons',799,0,'approved'),
 ('Baksa Tales team','Getting ready for corporate orders','Lead times, bulk pricing, personalisation and packaging that travels well.','live','Saturday 5 December, 11 am',1200,30,'approved');

-- Editable site content
create table public.site_content (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
grant select on public.site_content to anon, authenticated;
grant insert, update on public.site_content to authenticated;
grant all on public.site_content to service_role;
alter table public.site_content enable row level security;
create policy "content readable" on public.site_content for select to anon, authenticated using (true);
create policy "admin edits content" on public.site_content for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

insert into public.site_content (key, value) values
 ('hero', '{"eyebrow":"Dil se duniya tak","headline":"Every creation has a story.","subline":"Find the one that speaks to yours.","lede":"Open the baksa: real makers from across India, the stories behind their work, and the pieces you’ll want to give."}'),
 ('table', '{"kicker":"Curated craft carnival, Delhi NCR","title":"Kala Samāgam","body":"Meet the makers, hold the work, hear the stories in person. Plus DSDT — Dil Se Duniya Tak: live conversations with founders.","date":"Dates to be announced","cta":"Join the waitlist"}'),
 ('circle', '{"title":"Join the Baksa circle","body":"New maker stories, early access to Kala Samāgam and first look at limited drops, on WhatsApp. One message a week at most."}'),
 ('corporate', '{"title":"Gifts your team will actually keep","body":"Tell us the occasion, headcount and budget. We match you with makers who can deliver, personalised and on time."}');

-- Circle / waitlist signups and corporate enquiries
create table public.leads (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('circle','table','corporate')),
  name text not null check (char_length(name) between 1 and 100),
  contact text not null check (char_length(contact) between 5 and 120),
  details text check (char_length(details) <= 1000),
  created_at timestamptz not null default now()
);
grant insert on public.leads to anon, authenticated;
grant select on public.leads to authenticated;
grant all on public.leads to service_role;
alter table public.leads enable row level security;
create policy "anyone can sign up" on public.leads for insert to anon, authenticated with check (true);
create policy "admin reads leads" on public.leads for select to authenticated using (public.has_role(auth.uid(),'admin'));
