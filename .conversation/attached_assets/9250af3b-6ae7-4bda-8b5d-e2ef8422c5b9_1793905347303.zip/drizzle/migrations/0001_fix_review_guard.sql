create or replace function public.guard_product_review()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  -- Only signed-in non-admin app users are restricted; admins and trusted backend work pass through.
  if coalesce(auth.role(), '') not in ('anon','authenticated') or public.has_role(auth.uid(),'admin') then
    if tg_op = 'UPDATE' and new.status is distinct from old.status then new.reviewed_at := now(); end if;
    return new;
  end if;
  if tg_op = 'INSERT' or new.name is distinct from old.name or new.description is distinct from old.description
     or new.price_inr is distinct from old.price_inr or new.status is distinct from old.status
     or new.image_url is distinct from old.image_url then
    new.status := 'pending'; new.review_note := null; new.reviewed_at := null;
  end if;
  if tg_op = 'UPDATE' then new.maker_id := old.maker_id; end if;
  return new;
end $$;

update public.products set status = 'approved', reviewed_at = now()
where maker_id = '00000000-0000-0000-0000-0000000000a1';