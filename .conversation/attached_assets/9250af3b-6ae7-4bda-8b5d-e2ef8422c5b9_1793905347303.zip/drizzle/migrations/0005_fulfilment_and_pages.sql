ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS fulfilment text NOT NULL DEFAULT 'paid';
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS fulfilment_updated_at timestamptz;

CREATE OR REPLACE FUNCTION public.update_fulfilment(_order_item_id uuid, _status text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF _status NOT IN ('paid','making','shipped','delivered') THEN RAISE EXCEPTION 'Unknown status'; END IF;
  UPDATE public.order_items SET fulfilment = _status, fulfilment_updated_at = now()
  WHERE id = _order_item_id AND (maker_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
  IF NOT FOUND THEN RAISE EXCEPTION 'Not allowed'; END IF;
END $$;
REVOKE EXECUTE ON FUNCTION public.update_fulfilment(uuid,text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.update_fulfilment(uuid,text) TO authenticated;

CREATE TABLE public.site_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  kind text NOT NULL DEFAULT 'page',
  footer_column text,
  sort int NOT NULL DEFAULT 0,
  published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_pages TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_pages TO authenticated;
GRANT ALL ON public.site_pages TO service_role;
ALTER TABLE public.site_pages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Published pages are public" ON public.site_pages FOR SELECT USING (published OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins manage pages" ON public.site_pages FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));