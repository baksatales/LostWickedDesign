CREATE TABLE public.return_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id uuid NOT NULL UNIQUE REFERENCES public.order_items(id) ON DELETE CASCADE,
  shopper_id uuid NOT NULL,
  maker_id uuid NOT NULL,
  reason text NOT NULL CHECK (char_length(reason) BETWEEN 3 AND 600),
  status text NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','approved','declined','refunded')),
  maker_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.return_requests TO authenticated;
GRANT ALL ON public.return_requests TO service_role;
ALTER TABLE public.return_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "shopper reads own returns" ON public.return_requests FOR SELECT TO authenticated USING (shopper_id = auth.uid());
CREATE POLICY "maker reads their returns" ON public.return_requests FOR SELECT TO authenticated USING (maker_id = auth.uid());
CREATE POLICY "admin reads returns" ON public.return_requests FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "maker or admin updates returns" ON public.return_requests FOR UPDATE TO authenticated
  USING (maker_id = auth.uid() OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (maker_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

-- Shoppers request returns only through this function: checks ownership and the return window.
CREATE OR REPLACE FUNCTION public.request_return(_order_item_id uuid, _reason text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE it record; new_id uuid; window_days int := 7;
BEGIN
  SELECT oi.id, oi.maker_id, o.shopper_id, o.created_at INTO it
  FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE oi.id = _order_item_id;
  IF it.id IS NULL OR it.shopper_id <> auth.uid() THEN RAISE EXCEPTION 'Order not found'; END IF;
  IF it.created_at < now() - make_interval(days => window_days) THEN RAISE EXCEPTION 'The % day return window has closed', window_days; END IF;
  INSERT INTO return_requests(order_item_id, shopper_id, maker_id, reason)
  VALUES (_order_item_id, auth.uid(), it.maker_id, trim(_reason)) RETURNING id INTO new_id;
  RETURN new_id;
END $$;
REVOKE ALL ON FUNCTION public.request_return(uuid, text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.request_return(uuid, text) TO authenticated;