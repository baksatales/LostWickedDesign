<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Shoppers give handmade gifts that suit the person, and makers earn from their craft

## Metric

Orders paid each week
